<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class contact_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function writeToNP(){
        $username = $this->input->post('username');
        $email = $this->input->post('email');
        $theme = $this->input->post('theme');
        $content = $this->input->post('content');
        $username = $this->checker->tsh($username);
        $email = $this->checker->tsh($email);
        $theme = $this->checker->tsh($theme);
        $content = $this->checker->tsh($content);
        $this->load->library('email');
        $config['useragent'] = 'napulse.kz';
        $this->email->initialize($config);
        $this->email->from($email, $username);
        $this->email->to('office@napulse.kz');        
        $this->email->subject($theme);
        $this->email->message($content);	
        $this->email->send();
    }
    function editInfo(){
        $phone = $this->input->post('phone');
        $email = $this->input->post('email');
        $fax = $this->input->post('fax');
        $vk = $this->input->post('vk');
        $id = $this->input->post('contact_id');
        $facebook = $this->input->post('facebook');
        $postcode = $this->input->post('postcode');
        $address = $this->input->post('address');
        $id = $this->checker->tsh($id);
        $phone = $this->checker->tsh($phone);
        $email = $this->checker->tsh($email);
        $fax = $this->checker->tsh($fax);
        $vk = $this->checker->tsh($vk);
        $facebook = $this->checker->tsh($facebook);
        $postcode = $this->checker->tsh($postcode);
        $address = $this->checker->tsh($address);
        $data = array(
            'contact_phone' => $phone,
            'contact_email' => $email,
            'contact_fax' => $fax,
            'contact_vkontakte' => $vk,
            'contact_facebook' => $facebook,
            'contact_postcode' => $postcode,
            'contact_address' => $address,
        );
        $this->db->where('contact_id', $id);
        $this->db->update('contacts',$data);
    }
}
?>