<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class blog_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function blog_add($filename){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_short_info = $this->input->post('post_short_info');
        $post_content = $this->input->post('post_content');
        $post_category = $this->input->post('post_category');
        $post_cloud = $this->input->post('post_cloud');
        $post_title = $this->checker->tsh($post_title);
        $post_short_info = $this->checker->tsh($post_short_info);
        $post_content = $this->checker->tsh($post_content);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $post_category = $this->checker->tsh($post_category);
        $post_cloud = $this->checker->tsh($post_cloud);
        $data = array(
            'user_login' => $post_user_login,
            'blog_title' => $post_title,
            'blog_short_info' => $post_short_info,
            'user_id' => $post_user_id,
            'blog_content' => $post_content,
            'blog_photo' => base_url().'img/content/blog/'.$filename,
            'blog_category_id' => $post_category,
            'blog_tags' => $post_cloud,
        );
        $this->db->insert('blog',$data);
    }
    function blog_edit($id,$filename){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_short_info = $this->input->post('post_short_info');
        $post_content = $this->input->post('post_content');
        $post_category = $this->input->post('post_category');
        $post_cloud = $this->input->post('post_cloud');
        $post_title = $this->checker->tsh($post_title);
        $post_short_info = $this->checker->tsh($post_short_info);
        $post_content = $this->checker->tsh($post_content);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $post_category = $this->checker->tsh($post_category);
        $post_cloud = $this->checker->tsh($post_cloud);
        $data = array(
            'user_login' => $post_user_login,
            'blog_title' => $post_title,
            'blog_short_info' => $post_short_info,
            'user_id' => $post_user_id,
            'blog_content' => $post_content,
            'blog_photo' => base_url().'img/content/blog/'.$filename,
            'blog_category_id' => $post_category,
            'blog_tags' => $post_cloud,
        );
        $this->db->where('blog_id',$id);
        $this->db->update('blog',$data);
        $this->db->query("UPDATE np_blog SET blog_last_edit = NOW() WHERE blog_id = '$id' LIMIT 1");
    }
    function comment_add($blog_id){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_content = $this->input->post('post_content');
        $request_user_id = $this->input->post('request_user_id');
        $post_content = $this->checker->tsh($post_content);
        $request_user_id = $this->checker->tsh($request_user_id);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $this->db->where('blog_id',$blog_id);
        $query_count = $this->db->get('blog');
        $result = $query_count->row_array();
        $count_comments = $result['blog_count_com'];
        $count_comments += 1;
        $data_com = array(
            'blog_count_com' => $count_comments,
        );
        $this->db->where('blog_id',$blog_id);
        $this->db->update('blog',$data_com);
        $data = array(
            'user_id' => $post_user_id,
            'user_login' => $post_user_login,
            'blog_id' => $blog_id,
            'blog_title' => $result['blog_title'],
            'com_content' => $post_content,
        );
        if(is_numeric($request_user_id)){
            $this->db->where('user_id',$request_user_id);
            $query = $this->db->get('users');
            $rows = $query->row_array();
            $request_user_login = $rows['user_login'];
            $data['request_user_login'] = $request_user_login;
            $data['request_user_id'] = $request_user_id;
        }
        $this->db->insert('comments',$data);
    }
    function comment_edit($id){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_content = $this->input->post('post_content');
        $request_user_id = $this->input->post('request_user_id');
        $post_content = $this->checker->tsh($post_content);
        $request_user_id = $this->checker->tsh($request_user_id);
        if($request_user_id == 0) $request_user_id = '';
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $data = array(
            'user_id' => $post_user_id,
            'user_login' => $post_user_login,
            'com_content' => $post_content,
        );
        if(is_numeric($request_user_id)){
            $this->db->where('user_id',$request_user_id);
            $query = $this->db->get('users');
            $rows = $query->row_array();
            $request_user_login = $rows['user_login'];
            $data['request_user_login'] = $request_user_login;
            $data['request_user_id'] = $request_user_id;
        }
        $this->db->where('com_id',$id);
        $this->db->update('comments',$data);
        $this->db->query("UPDATE np_comments SET com_last_edit = NOW() WHERE com_id = '$id' LIMIT 1");
    }
    function category_add(){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_title = $this->checker->tsh($post_title);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $data = array(
            //'user_id' => $post_user_id,
            //'user_login' => $post_user_login,
            'cat_title' => $post_title,
        );
        $this->db->insert('category',$data);
    }
    function category_edit($id){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_title = $this->checker->tsh($post_title);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $data = array(
            //'user_id' => $post_user_id,
            //'user_login' => $post_user_login,
            'cat_title' => $post_title,
        );
        $this->db->where('cat_id',$id);
        $this->db->update('category',$data);
    }
    function tags_add(){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_title = $this->checker->tsh($post_title);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $data = array(
            //'user_id' => $post_user_id,
            //'user_login' => $post_user_login,
            'cloud_title' => $post_title,
        );
        $this->db->insert('cloud',$data);
    }
    function tags_edit($id){
        $CI = &get_instance();
        $post_user_id = $CI->session->userdata('id');
        $post_user_login = $CI->session->userdata('login');
        $post_title = $this->input->post('post_title');
        $post_title = $this->checker->tsh($post_title);
        $post_user_id = $this->checker->tsh($post_user_id);
        $post_user_login = $this->checker->tsh($post_user_login);
        $data = array(
            //'user_id' => $post_user_id,
            //'user_login' => $post_user_login,
            'cloud_title' => $post_title,
        );
        $this->db->where('cloud_id',$id);
        $this->db->update('cloud',$data);
    }
}
?>