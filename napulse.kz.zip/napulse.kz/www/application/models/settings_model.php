<?php

/**
 * @author miracle
 * @copyright 2012
 */

if ( !defined('BASEPATH') ) exit('No direct script access allowed');

class settings_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function user_logoff(){
        $data_online = array(
            'user_online' => 0,
        );
        $this->db->where('user_id',$this->session->userdata('id'));
        $this->db->update('users',$data_online);
        $this->session->sess_destroy();
    }
    
    function user_auth(){
        $login = $this->session->userdata('login');
        if(!empty($login) && $this->session->userdata('logged_in')){
            $this->db->where('user_login',$this->session->userdata('login'));      
            $query = $this->db->get('users');
            $result = $query->row_array();
            if($result['user_banned'] == 1)
                $this->user_logoff();
            return true;
        }
        return false;
    }
    
    function user_admin(){
        $login = $this->session->userdata('login');
        if($this->session->userdata('user_admin'))
            $user_admin = $this->session->userdata('user_admin');
        if(!empty($login) && isset($user_admin) && $this->session->userdata('logged_in')){
            return true;
        }
        return false;
    }
}

?>