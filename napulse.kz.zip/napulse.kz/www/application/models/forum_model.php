<?php

/**
 * @author miracle
 * @copyright 2012
 */

if ( !defined('BASEPATH') ) exit('No direct script access allowed');

class forum_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function addCategory($user_id,$login){
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $data = array(
            'title' => $title,
            'user_id' => $user_id,
            'user_login' => $login,
        );
        $this->db->insert('forum_category',$data);
    }
    function addSubcategory($user_id,$login){
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $short_info = $this->input->post('short_info');
        $short_info = $this->checker->tsh($short_info);
        $category_id = $this->input->post('category_id');
        $category_id = $this->checker->tsh($category_id);
        $data = array(
            'title' => $title,
            'short_info' => $short_info,
            'category_id' => $category_id,
            'user_id' => $user_id,
            'user_login' => $login,
        );
        $this->db->insert('forum_subcategory',$data);
    }
    function addPost($user_id,$login){
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $content = $this->input->post('content');
        $content = $this->checker->tsh($content);
        $category_id = $this->input->post('category_id');
        $category_id = $this->checker->tsh($category_id);
        $subcategory_id = $this->input->post('subcategory_id');
        $subcategory_id = $this->checker->tsh($subcategory_id);
        $this->db->where('id',$subcategory_id);
        $this->db->where('category_id',$category_id);
        $q = $this->db->get('forum_subcategory');
        $r = $q->result_array();
        if($r){
        $data_post = array(
            'title' => $title,
            'subcategory_id' => $subcategory_id,
            'category_id' => $category_id,
            'user_id' => $user_id,
            'user_login' => $login,
        );
        $this->db->insert('forum_post',$data_post);
        $post_id = $this->db->insert_id();
        $data_message = array(
            'post_id' => $post_id,
            'user_id' => $user_id,
            'user_login' => $login,
            'subject' => $content,
        );
        $this->db->insert('forum_message',$data_message);
        $last_id = $this->db->insert_id();
        $this->db->where('id',$last_id);
        $q_date = $this->db->get('forum_message');
        $r_date = $q_date->row_array();
        $data_post = array(
            'last_post_id' => $post_id,
            'last_poster_id' => $user_id,
            'last_poster_login' => $login,
            'last_post_subject' => $content,
            'last_post_date' => $r_date['date_writed'],
        );
        $this->db->where('id',$post_id);
        $this->db->update('forum_post',$data_post);
        $this->db->where('id',$subcategory_id);
        $this->db->update('forum_subcategory',$data_post);
        $this->db->where('user_id',$user_id);
        $q_c_f_post = $this->db->get('users');
        $r_c_g_post = $q_c_f_post->row_array();
        $count_f_post = $r_c_g_post['user_c_f_post'] + 1;
        $count_f_msg = $r_c_g_post['user_c_f_msg'] + 1;
        $data_c_f = array(
            'user_c_f_post' => $count_f_post,
            'user_c_f_msg' => $count_f_msg,
        );
        $this->db->where('user_id',$user_id);
        $this->db->update('users',$data_c_f);
        }
    }
    function addComment($user_id,$login,$post_id,$msg_id){
        $this->load->helper('date');
        $subject = $this->input->post('subject');
        $subject = $this->checker->tsh($subject);
        $data_message = array(
            'post_id' => $post_id,
            'user_id' => $user_id,
            'user_login' => $login,
            'subject' => $subject,
        );
        if($msg_id != 0){
            $this->db->where('id',$msg_id);
            $q_info = $this->db->get('forum_message');
            $r_info = $q_info->row_array();
            $reply_id = $r_info['user_id'];
            $reply_login = $r_info['user_login'];
            $data_message['request_id'] = $reply_id;
            $data_message['request_login'] = $reply_login;
        }
        $this->db->insert('forum_message',$data_message);
        $this->db->where('id',$post_id);
        $q_date = $this->db->get('forum_post');
        $r_date = $q_date->row_array();
        $data_post = array(
            'last_post_id' => $post_id,
            'last_poster_id' => $user_id,
            'last_poster_login' => $login,
            'last_post_subject' => $subject,
            'last_post_date' => mdate("%Y-%m-%d %H:%i:%s",gmt_to_local(now(), 'UP6', FALSE)),
        );
        $this->db->where('id',$post_id);
        $this->db->update('forum_post',$data_post);
        $this->db->where('id',$r_date['subcategory_id']);
        $this->db->update('forum_subcategory',$data_post);
        $this->db->where('user_id',$user_id);
        $q_c_f_post = $this->db->get('users');
        $r_c_g_post = $q_c_f_post->row_array();
        $count_f_msg = $r_c_g_post['user_c_f_msg'] + 1;
        $data_c_f = array(
            'user_c_f_msg' => $count_f_msg,
        );
        $this->db->where('user_id',$user_id);
        $this->db->update('users',$data_c_f);
    }
    function editCategory($id){
        $this->load->helper('date');
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $data = array(
            'title' => $title,
            'date_modify' => mdate("%Y-%m-%d %H:%i:%s",gmt_to_local(now(), 'UP6', FALSE)),
        );
        $this->db->where('id',$id);
        $this->db->update('forum_category',$data);
    }
    function editSubcategory($id){
        $this->load->helper('date');
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $short_info = $this->input->post('short_info');
        $short_info = $this->checker->tsh($short_info);
        $category_id = $this->input->post('category_id');
        $category_id = $this->checker->tsh($category_id);
        $data = array(
            'title' => $title,
            'short_info' => $short_info,
            'category_id' => $category_id,
            'date_modify' => mdate("%Y-%m-%d %H:%i:%s",gmt_to_local(now(), 'UP6', FALSE)),
        );
        $this->db->where('id',$id);
        $this->db->update('forum_subcategory',$data);
    }
    function editPost($id){
        $this->load->helper('date');
        $title = $this->input->post('title');
        $title = $this->checker->tsh($title);
        $category_id = $this->input->post('category_id');
        $category_id = $this->checker->tsh($category_id);
        $subcategory_id = $this->input->post('subcategory_id');
        $subcategory_id = $this->checker->tsh($subcategory_id);
        $data = array(
            'title' => $title,
            'category_id' => $category_id,
            'subcategory_id' => $subcategory_id,
            'date_modify' => mdate("%Y-%m-%d %H:%i:%s",gmt_to_local(now(), 'UP6', FALSE)),
        );
        $this->db->where('id',$id);
        $this->db->update('forum_post',$data);
    }
    function editMessage($id){
        $this->load->helper('date');
        $subject = $this->input->post('subject');
        $subject = $this->checker->tsh($subject);
        $data = array(
            'subject' => $subject,
            'date_modify' => mdate("%Y-%m-%d %H:%i:%s",gmt_to_local(now(), 'UP6', FALSE)),
        );
        $this->db->where('id',$id);
        $this->db->update('forum_message',$data);
    }
    function deleteCategory($id){
        $this->db->where('category_id',$id);
        $q_s = $this->db->get('forum_subcategory');
        $r_s = $q_s->result_array();
        foreach($r_s as $key => $value){
            $this->db->where('subcategory_id',$value['id']);
            $q_p = $this->db->get('forum_post');
            $r_p = $q_p->result_array();
            foreach($r_p as $key2 => $value2){
                $this->db->where('post_id',$value2['id']);
                $this->db->delete('forum_message');
            }
            $this->db->where('subcategory_id',$value['id']);
            $this->db->delete('forum_post');
        }
        $this->db->where('category_id',$id);
        $this->db->delete('forum_subcategory');
        $this->db->where('id',$id);
        $this->db->delete('forum_category');
    }
    function deleteSubcategory($id){
        $this->db->where('subcategory_id',$id);
        $q_p = $this->db->get('forum_post');
        $r_p = $q_p->result_array();
        foreach($r_p as $key => $value){
            $this->db->where('post_id',$value['id']);
            $this->db->delete('forum_message');
        }
        $this->db->where('subcategory_id',$id);
        $this->db->delete('forum_post');
        $this->db->where('id',$id);
        $this->db->delete('forum_subcategory');
    }
    function deletePost($id){
        $this->db->where('id',$id);
        $this->db->delete('forum_post');
    }
    function deleteMessage($id){
        $this->db->where('id',$id);
        $this->db->delete('forum_message');
    }
    function guestGone(){
        $guest_agent = $this->input->user_agent();
        $guest_ip = $this->input->ip_address();
        $this->load->helper('date');
        $data = array(
            'guest_ip' => $guest_ip,
            'guest_agent' => $guest_agent,
            'guest_date' => gmt_to_local(now(), 'UP6', FALSE),
        );
        $this->db->where('guest_ip',$guest_ip);
        $q = $this->db->get('guests');
        $r = $q->result_array();
        if($r){
            $this->db->where('guest_ip',$guest_ip);
            $this->db->update('guests',$data);
        } else {
            $this->db->insert('guests',$data);
        }
    }
}

?>