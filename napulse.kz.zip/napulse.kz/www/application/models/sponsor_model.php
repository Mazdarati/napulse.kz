<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class sponsor_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function sponsor_add($img){
        $CI = &get_instance();
        $user_id = $CI->session->userdata('id');
        $user_login = $CI->session->userdata('login');
        $title = $this->input->post('title');
        $content = $this->input->post('content');
        $title = $this->checker->tsh($title);
        $content = $this->checker->tsh($content);
        $user_id = $this->checker->tsh($user_id);
        $user_login = $this->checker->tsh($user_login);
        $data = array(
            'user_login' => $user_login,
            'partner_title' => $title,
            'user_id' => $user_id,
            'partner_descr' => $content,
            'partner_image' => base_url().'img/content/sponsor/'.$img,
        );
        $this->db->insert('partner',$data);
    }
    function sponsor_edit($id,$img){
        $CI = &get_instance();
        $user_id = $CI->session->userdata('id');
        $user_login = $CI->session->userdata('login');
        $title = $this->input->post('title');
        $content = $this->input->post('content');
        $title = $this->checker->tsh($title);
        $content = $this->checker->tsh($content);
        $user_id = $this->checker->tsh($user_id);
        $user_login = $this->checker->tsh($user_login);
        $data = array(
            'user_login' => $user_login,
            'partner_title' => $title,
            'user_id' => $user_id,
            'partner_descr' => $content,
            'partner_image' => base_url().'img/content/sponsor/'.$img,
        );
        $this->db->where('partner_id',$id);
        $this->db->update('partner',$data);
        $this->db->query("UPDATE np_partner SET partner_date_modify = NOW() WHERE partner_id = '$id' LIMIT 1");
    }
    function sponsor_remove($id){
        $this->db->where('partner_id',$id);
        $this->db->delete('partner');
    }
}
?>