<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class user_model extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    function check_login(){
         $log_or_email = $this->input->post('log_or_email');
         $password = $this->input->post('pass');
         $log_or_email = $this->checker->tsh($log_or_email);
         $password = $this->checker->tsh($password);
         $this->db->where('user_password',$password);
         $this->db->where('user_banned',0);
         $this->db->where('user_login',$log_or_email);
         $this->db->or_where('user_email',$log_or_email);
         $query = $this->db->get('users');
         $res = $query->row_array();
         if($res){
            $data = array(
                'login' => $res['user_login'],
                'email' => $res['user_email'],
                'id' => $res['user_id'],
                'logged_in' => true,
                'ip_address' => $this->input->ip_address(),
                'user_agent' => $this->input->user_agent(),
            );
            $this->db->where('user_id',$res['user_id']);
            $this->db->where('user_login',$res['user_login']);
            $q_adm = $this->db->get('admins');
            $res_adm = $q_adm->result_array();
            if($res_adm){
                $data['user_admin'] = $res['user_id'];
            }
            $data_online = array(
                'user_online' => 1,
            );$id = $res['user_id'];
            $this->db->where('user_id',$id);
            $this->db->update('users',$data_online);
            $this->db->query("UPDATE np_users SET user_last_login = NOW() WHERE user_id = '$id' LIMIT 1");
            $this->session->set_userdata($data);
         }
    }
    function signup(){
        $captcha_code = $this->input->post('captcha_code');
        $email = $this->input->post('email');
        $login = $this->input->post('login');
        $password = $this->input->post('password');
        $d_password = $this->input->post('d_password');
        $captcha_code = $this->checker->tsh($captcha_code);
        $email = $this->checker->tsh($email);
        $login = $this->checker->tsh($login);
        $password = $this->checker->tsh($password);
        $d_password = $this->checker->tsh($d_password);
        $data = array(
            'user_login' => $login,
            'user_password' => $password,
            'user_email' => $email,
        );
        if(!$this->check_code($captcha_code)){
            exit('Неправильная каптча');
        } else {
            $this->db->insert('users',$data);
        }
    }
    function editProfile($user_login) {
        $surname = $this->input->post('surname');
        $name = $this->input->post('username');
        $patronymic = $this->input->post('patronymic');
        $gender = $this->input->post('gender');
        $d_birthday = $this->input->post('day_of_birthday');
        $m_birthday = $this->input->post('month_of_birthday');
        $y_birthday = $this->input->post('year_of_birthday');
        $town = $this->input->post('town');
        $surname = $this->checker->tsh($surname);
        $name = $this->checker->tsh($name);
        $patronymic = $this->checker->tsh($patronymic);
        $gender = $this->checker->tsh($gender);
        $d_birthday = $this->checker->tsh($d_birthday);
        $m_birthday = $this->checker->tsh($m_birthday);
        $y_birthday = $this->checker->tsh($y_birthday);
        $town = $this->checker->tsh($town);
        $data = array(
            'user_surname' => $surname,
            'user_name' => $name,
            'user_patronymic' => $patronymic,
            'user_gender' => $gender,
            'user_birthday' => $y_birthday.'-'.$m_birthday.'-'.$d_birthday,
            'user_town' => $town,
        );
        $this->db->where('user_login',$user_login);
        $this->db->update('users',$data);
    }
    function editPassword($user_login) {
        $cur_password = $this->input->post('cur_password');
        $new_password = $this->input->post('new_password');
        $confirm_password = $this->input->post('confirm_password');
        $cur_password = $this->checker->tsh($cur_password);
        $new_password = $this->checker->tsh($new_password);
        $confirm_password = $this->checker->tsh($confirm_password);
        $this->db->where('user_login',$user_login);
        $query_password = $this->db->get('users');
        $result_password = $query_password->row_array();
        if($result_password['user_password'] == $cur_password){
            if($new_password == $confirm_password){
                $data = array(
                    'user_password' => $new_password,
                );
                $this->db->where('user_login',$user_login);
                $this->db->update('users',$data);
            }
        }
    }
    function editEmail($user_login) {
        $cur_email = $this->input->post('cur_email');
        $new_email = $this->input->post('new_email');
        $confirm_email = $this->input->post('confirm_email');
        $cur_email = $this->checker->tsh($cur_email);
        $new_email = $this->checker->tsh($new_email);
        $confirm_email = $this->checker->tsh($confirm_email);
        $this->db->where('user_login',$user_login);
        $query_email = $this->db->get('users');
        $result_email = $query_email->row_array();
        if($result_email['user_email'] == $cur_email){
            if($new_email == $confirm_email){
                $data = array(
                    'user_email' => $new_email,
                );
                $this->db->where('user_login',$user_login);
                $this->db->update('users',$data);
            }
        }
    }
    function sendMessage($user_login) {
        $theme = $this->input->post('theme');
        $content = $this->input->post('content');
        $theme = $this->checker->tsh($theme);
        $content = $this->checker->tsh($content);
        $from_id = $this->session->userdata('id');
        $this->db->where('user_login',$user_login);
        $q_id = $this->db->get('users');
        $r_id = $q_id->row_array();
        $to_id = $r_id['user_id'];
        $data = array(
            'msg_to_id' => $to_id,
            'msg_from_id' => $from_id,
            'msg_theme' => $theme,
            'msg_content' =>$content,
        );
        $this->db->insert('message',$data);
    }
    function banUser($user_login) {
        $day = $this->input->post('day_of_ban');
        $month = $this->input->post('month_of_ban');
        $year = $this->input->post('year_of_ban');
        $day = $this->checker->tsh($day);
        $month = $this->checker->tsh($month);
        $year = $this->checker->tsh($year);
        $data = array(
            'user_banned' => 1,
            'user_banned_date' => $year.'-'.$month.'-'.$day,
        );
        $this->db->where('user_login',$user_login);
        $this->db->update('users',$data);
    }
    function removeUser($user_login) {
        $this->db->where('user_login',$user_login);
        $this->db->delete('users');
    }
    function generate_code() {
        $hours = date("H"); // час       
        $minuts = substr(date("H"), 0 , 1);// минута 
        $mouns = date("m");    // месяц             
        $year_day = date("z"); // день в году
    
        $str = $hours . $minuts . $mouns . $year_day; //создаем строку
        $str = md5(md5($str)); //дважды шифруем в md5
    	$str = strrev($str);// реверс строки
    	$str = substr($str, 3, 6); // извлекаем 6 символов, начиная с 3
    	// Вам конечно же можно постваить другие значения, так как, если взломщики узнают, каким именно способом это все генерируется, то в защите не будет смысла.
    	
    
        $array_mix = preg_split('//', $str, -1, PREG_SPLIT_NO_EMPTY);
        srand ((float)microtime()*1000000);
        shuffle ($array_mix);
    	//Тщательно перемешиваем, соль, сахар по вкусу!!!
        return implode("", $array_mix);
    }
    function check_code($code) {
        $code = trim($code);//удаляем пробелы
    
        $array_mix = preg_split ('//', $this->generate_code(), -1, PREG_SPLIT_NO_EMPTY);
        $m_code = preg_split ('//', $code, -1, PREG_SPLIT_NO_EMPTY);
    
        $result = array_intersect ($array_mix, $m_code);
        if (strlen($this->generate_code())!=strlen($code))
        {
            return FALSE;
        }
        if (sizeof($result) == sizeof($array_mix))
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
}
?>