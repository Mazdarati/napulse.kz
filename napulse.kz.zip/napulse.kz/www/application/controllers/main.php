<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
        1 - молчу
*/
class Main extends CI_Controller {

    public function index() {
        $data_header = array(
            'title' => 'Главная',
        );
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $data_slider = array();
        $this->parser->parse('site_slider',$data_slider);
        $this->_footer();
	}
    public function auth($action) {
	   $action = trim($action);
       $action = htmlspecialchars($action);
       $action = stripslashes($action);
       if (($action != 'login') && ($action != 'signup') && ($action != 'logout')) { unset($action); } 
	   if(isset($action)) {
	       if($action == 'logout'){
	           $this->settings_model->user_logoff();
               redirect('/');
           }
	       if($action == 'login'){
               $rules = array(
                    array(
                        'field' => 'log_or_email',
                        'label' => 'Логин( или почту)',
                        'rules' => 'trim|required|min_length[3]|max_length[40]',
                    ),
                    array(
                        'field' => 'pass',
                        'label' => 'Пароль',
                        'rules' => 'trim|required|min_length[3]|max_length[40]',
                    ),
                    
               );
           } else {
                $rules = array(
                    array(
                        'field' => 'login',
                        'label' => 'логин',
                        'rules' => 'trim|required|min_length[3]|max_length[40]',
                    ),
                    array(
                        'field' => 'password',
                        'label' => 'пароль',
                        'rules' => 'trim|required|min_length[3]|max_length[40]|matches[d_password]',
                    ),
                    array(
                        'field' => 'd_password',
                        'label' => 'Повторите пароль',
                        'rules' => 'required',
                    ),
                    array(
                        'field' => 'email',
                        'label' => 'почта',
                        'rules' => 'trim|required|min_length[3]|max_length[40]|valid_email',
                    ),
               );
           }
           $this->form_validation->set_rules($rules);
	       if($this->form_validation->run() == FALSE){         
                if($action == 'login'){
                    $data_login = array();
                    $this->parser->parse('site_login',$data_login);
                } else {
                    $data_signup = array();
                    $this->parser->parse('site_signup',$data_signup);
                }
            } else {
                $this->load->model('user_model');
                if($action == 'login'){
                    $this->user_model->check_login();
                    $data_login = array();
                    $this->parser->parse('site_login',$data_login);
                    redirect('/');
                } else {
                    $this->user_model->signup();
                    redirect('/');
                }
            }
        } else {
            redirect('/');
        }
    }
    public function purpose() {
        /*** Include Header ***/
        
        $data_header = array(
            'title' => 'Цели сайта',
        );
        $this->parser->parse('site_header',$data_header);
        
        /*** Include Styles ***/
        
        $data_load_css = array(
            'url_style' => 'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => 'scripts/jquery.min.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => 'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);        
        /*** Include content ***/
        
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_purpose_active' => "background:url('img/link/own_profile_link-right.png') no-repeat right,url('img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
        $data_purpose = array();
        $this->parser->parse('site_purpose',$data_purpose);
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
    public function history($action) {
        /*** Include Header ***/
        
        $data_header = array(
            'title' => '',
        );
        $this->parser->parse('site_header',$data_header);
        $data_load_css = array(
            'url_style' => 'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        $data_load_scripts = array(
            'url_scripts' => 'scripts/jquery.min.js',
        );  
        $this->parser->parse('site_load_scripts',$data_load_scripts);        
        /*** Include content ***/
        
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array();
        $this->parser->parse('site_menu',$data_menu);

        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
    function _include(){
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        $data_load_css = array(
            'url_style' => base_url().'styles/anythingslider.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        );  
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.anythingslider.min.js',
        );  
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.easing.1.2.js',
        );  
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Previews.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Previews(); Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array();
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}