<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
    ajax запросы
*/
class Sponsor extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->_show();
    }
    function _show(){
        /*** Include Header ***/
        
        $data_header = array(
            'title' => 'Наши партнеры',
        );
        $this->parser->parse('site_header',$data_header);
        
        $this->_include();
        
        $query = $this->db->get('partner');
        $data_sponsor = array(
            'sponsors' => $query->result_array(),
        );
        $this->parser->parse('site_sponsor',$data_sponsor);
        $this->_footer();
    }
    public function add(){
        if(!$this->settings_model->user_admin()){
            redirect('/sponsor');
            exit(1);
        }
        $rules = array(
            array(
                    'field' => 'title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'content',
                    'label' => 'Описание',
                    'rules' => 'trim|required|min_length[3]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $this->_include();
            $data_header = array(
                'title' => 'Добавить спонсора',
            );
            $this->parser->parse('site_header',$data_header);
            $data_sponsor_add = array(
                'error' => '',
            );
            $this->parser->parse('site_sponsor_add',$data_sponsor_add);
            $this->_footer();
        } else {
            $config['upload_path'] = 'img/content/sponsor/';
      		$config['allowed_types'] = 'gif|jpg|png|jpeg';
      		$config['max_size']	= '300';
      		$config['max_width']  = '235';
      		$config['max_height']  = '60';
      		$this->load->library('upload', $config);
      		if ( ! $this->upload->do_upload()){
      		    $this->_include();
                $data_header = array(
                    'title' => 'Добавить спонсора',
                );
                $this->parser->parse('site_header',$data_header);
     			$error = array('error' => $this->upload->display_errors());
                $this->parser->parse('site_sponsor_add',$error);
                $this->_footer();
      		} else {
                $this->load->model('sponsor_model');      		    
     			$data = $this->upload->data();
                $file_name = $data['file_name'];
     			$this->sponsor_model->sponsor_add($file_name);
                redirect('/sponsor');
      		}
        }
    }
    public function edit($id = ''){
        if(!$this->settings_model->user_admin()){
            redirect('/sponsor');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/sponsor');
        }
        $this->db->where('partner_id',$id);
        $query_sponsor = $this->db->get('partner');
        if(!$query_sponsor->row_array()){
            redirect('/sponsor');
        }
        $rules = array(
            array(
                    'field' => 'title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'content',
                    'label' => 'Описание',
                    'rules' => 'trim|required|min_length[3]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $this->_include();
            $data_header = array(
                'title' => 'Редактировать спонсора',
            );
            $this->parser->parse('site_header',$data_header);
            $data_sponsor_edit = array(
                'error' => '',
                'partner' => $query_sponsor->result_array(),
            );
            $this->parser->parse('site_sponsor_edit',$data_sponsor_edit);
            $this->_footer();
        } else {
            $config['upload_path'] = 'img/content/sponsor/';
      		$config['allowed_types'] = 'gif|jpg|png|jpeg';
      		$config['max_size']	= '300';
      		$config['max_width']  = '235';
      		$config['max_height']  = '60';
      		$this->load->library('upload', $config);
      		if ( ! $this->upload->do_upload()){
      		    $this->_include();
                $data_header = array(
                    'title' => 'Редактировать спонсора',
                );
                $this->parser->parse('site_header',$data_header);
                $this->db->where('partner_id',$id);
                $query_sponsor = $this->db->get('partner');
     			$error = array('error' => $this->upload->display_errors(),'partner' => $query_sponsor->result_array(),);
                $this->parser->parse('site_sponsor_edit',$error);
                $this->_footer();
      		} else {
                $this->load->model('sponsor_model');      		    
     			$data = $this->upload->data();
                $file_name = $data['file_name'];
     			$this->sponsor_model->sponsor_edit($id,$file_name);
                redirect('/sponsor');
      		}
        }
    }
    public function remove($id = ''){
        if(!$this->settings_model->user_admin()){
            redirect('/sponsor');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/sponsor');
        }
        $this->db->where('partner_id',$id);
        $query_sponsor = $this->db->get('partner');
        if(!$query_sponsor->row_array()){
            redirect('/sponsor');
        }
        $rules = array(
            array(
                'field' => 'remove',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $this->_include();
            $this->db->where('partner_id',$id);
            $query_sponsor = $this->db->get('partner');
            $data_sponsor_remove = array(
                'partner' => $query_sponsor->result_array(),
            );
            $this->parser->parse('site_sponsor_remove',$data_sponsor_remove);
            $this->_footer();
        } else {
            $this->load->model('sponsor_model');      		    
 			$this->sponsor_model->sponsor_remove($id);
            redirect('/sponsor');
        }
    }
    function _include(){      
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        ); 
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_sponsor_active' => "background:url('".base_url()."img/link/own_profile_link-right.png') no-repeat right,url('".base_url()."img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>