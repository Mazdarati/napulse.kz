<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Consultation extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->_show();
    }
    function _show(){
        $data_header = array(
            'title' => 'Консультация',
        );
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $data_consultation = array();
        $this->parser->parse('site_consultation',$data_consultation);
        $this->_footer();
    }
    function _include(){
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        ); 
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => 'scripts/jquery.min.js',
        );  
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_consultation_active' => "background:url('".base_url()."img/link/own_profile_link-right.png') no-repeat right,url('".base_url()."img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>