<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
        1 - молчу, тоже самое в блоге
*/
class News extends CI_Controller {
    
    public function Sponsor(){
        parent::__construct();
    }
    public function index(){
        $this->show();
    }
    public function show(){
        /*** Include Header ***/
        
        $data_header = array(
            'title' => 'Наши партнеры',
        );
        $this->parser->parse('site_header',$data_header);
        
        /*** Include Styles ***/
        
        $data_load_css = array(
            'url_style' => 'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => 'scripts/jquery.min.js',
        ); 
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => 'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);       
        /*** Include content ***/
        
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_news_active' => "background:url('img/link/own_profile_link-right.png') no-repeat right,url('img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
        $data_sponsor = array();
        $this->parser->parse('site_news',$data_sponsor);
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>