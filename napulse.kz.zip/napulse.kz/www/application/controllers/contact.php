<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
    1 - Модифицировать в массив записи в базу данных и вывод
*/
class Contact extends CI_Controller {
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->_show();
    }
    function _show(){
        $rules = array(
            array(
                    'field' => 'username',
                    'label' => 'Имя',
                    'rules' => 'trim|required|min_length[3]|max_length[50]',
            ),
            array(
                    'field' => 'email',
                    'label' => 'Почту',
                    'rules' => 'trim|required|min_length[3]|max_length[255]|valid_email',
            ),
            array(
                    'field' => 'theme',
                    'label' => 'Тему',
                    'rules' => 'trim|required|min_length[3]',
            ),
            array(
                    'field' => 'content',
                    'label' => 'Содержание',
                    'rules' => 'trim|required|min_length[15]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Наши контакты',
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();        
            $query = $this->db->get('contacts');
            $result = $query->row_array();
            $data_contact = array(
                'surname' => $result['contact_surname'],
                'name' => $result['contact_name'],
                'patronymic' => $result['contact_patronymic'],
                'numberphone' => $result['contact_phone'],
                'fax' => $result['contact_fax'],
                'email' => $result['contact_email'],
                'vkontakte' => $result['contact_vkontakte'],
                'skype' => $result['contact_skype'],
                'facebook' => $result['contact_facebook'],
                'postcode' => $result['contact_postcode'],
                'address' => $result['contact_address'],
            );
            $this->parser->parse('site_aboutus',$data_contact);
            $this->_footer();
        } else {
            $this->_write();
            redirect('/contact');
        }
    }
    function editinfo(){
        if(!$this->settings_model->user_admin()){
            redirect('/contact');
            exit(1);
        }
        $rules = array(
            // rules all input or disable
            array(
                'field' => 'phone',
                'label' => 'Номер телефонов',
                'rules' => 'trim|required|min_length[3]|max_length[50]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Редактировать контакты',
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();        
            $query = $this->db->get('contacts');
            $result = $query->row_array();
            $data_edit_aboutus = array(
                'id' => $result['contact_id'],
                'surname' => $result['contact_surname'],
                'name' => $result['contact_name'],
                'patronymic' => $result['contact_patronymic'],
                'numberphone' => $result['contact_phone'],
                'fax' => $result['contact_fax'],
                'email' => $result['contact_email'],
                'vkontakte' => $result['contact_vkontakte'],
                'skype' => $result['contact_skype'],
                'facebook' => $result['contact_facebook'],
                'postcode' => $result['contact_postcode'],
                'address' => $result['contact_address'],
            );
            $this->parser->parse('site_edit_aboutus',$data_edit_aboutus);
            $this->_footer();
        } else {
            $this->_editInformation();
            redirect('/contact');
        }
    }
    function _editInformation(){
        $this->load->model('contact_model');
        $this->contact_model->editInfo();
    }
    function _write(){
        $this->load->model('contact_model');
        $this->contact_model->writeToNP();
    }
    function _include(){
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array();
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>