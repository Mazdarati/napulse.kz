<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Forum extends CI_Controller {
    public function __construct(){
        parent::__construct();
    }
    function _remap($method,$action){
        $method = $this->checker->tsh($method);
        $this->load->model('forum_model');
        if(!$this->settings_model->user_auth())
            $this->forum_model->guestGone();
        if($method == "index"){
            $this->_show();
        } else if($method == "manage") {
            if(!$this->settings_model->user_admin())
                show_404();
            if(count($action) < 1){
                show_404();
            } if($action[0] != "edit" && $action[0] != "add" && 
                $action[0] != "addSub" && $action[0] != "delete"){
                show_404();
            } if($action[0] == "edit" || $action[0] == "delete"){
                if(count($action) < 3){
                    show_404();
                } if ($action[1] != "c" && $action[1] != "s"){
                    show_404();
                }
                if(!is_numeric($action[2])){
                    show_404();
                }
            }
            $this->_manage($action);
        } else if($method == "view") {
            if(count($action) > 4){
                show_404();
            } if($action[0] != "c" && $action[0] != "s" && $action[0] != "p"){
                show_404();
            } if(!is_numeric($action[1])){
                show_404();
            } if(isset($action[2])) {
                if($action[2] != "page"){
                    show_404();
                }
                if(isset($action[3])) {
                   if(!is_numeric($action[3])){
                    show_404();
                   }
                } else {
                    $action[3] = 0;
                }
            } else {
               $action[2] = "page";
               $action[3] = 0; 
            } 
            $this->_view($action);
        } else if($method == "posting") {
            if(!$this->settings_model->user_auth())
                show_404();
            if(count($action) > 5){
                show_404();
            } if(count($action) < 1 || ($action[0] != "post" && $action[0] != "delete"
                && $action[0] != "edit" && $action[0] != "reply")){
                show_404();
            } if(count($action) < 3 && $action[0] == "edit"){
                show_404();
            } if($action[0] == "edit" && $action[1] != "p" && $action[1] != "m"){
                show_404();
            } if($action[0] == "edit" && !is_numeric($action[2])){
                show_404();
            } if(count($action) < 3 && $action[0] == "delete"){
                show_404();
            } if($action[0] == "delete" && $action[1] != "p" && $action[1] != "m"){
                show_404();
            } if($action[0] == "delete" && !is_numeric($action[2])){
                show_404();
            } if(count($action) < 3 && $action[0] == "reply"){
                show_404();
            } if($action[0] == "reply" && $action[1] != "p"){
                show_404();
            } if($action[0] == "reply" && !is_numeric($action[2])){
                show_404();
            }
            $this->_posting($action);
        } else if($method == "search") {
            $search = $_GET['q'];
            $search = $this->checker->tsh($search);
            $author = ''; $type = 'msg';$page = 0;
            if(isset($_GET['author'])){
                $author = $_GET['author'];
                $author = $this->checker->tsh($author);
            }
            if(isset($_GET['type'])){
                $type = $_GET['type'];
                $type = $this->checker->tsh($type);
            }
            if(isset($_GET['per_page'])){
                $page = $_GET['per_page'];
                $page = $this->checker->tsh($page);
            }
            if($search != '[removed]'){
                $this->_search($page,$search,$author,$type);
            }
        } else {
            show_404();
        }
    }
    function _show(){
        $data_header = array(
            'title' => 'Форум',
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $mod_on = array();
        if($this->settings_model->user_admin())
            $mod_on = array(array(1));
            
        $statistic = array();
        $this->db->where('user_online',1);
        $q_online_u = $this->db->get('users');
        $statistic[0]['online_user'] = $q_online_u->num_rows();
        $this->load->helper('date');
        $time = now() - 300;
        $this->db->where('guest_date > ', gmt_to_local($time, 'UP6', FALSE));
        $q_online_g = $this->db->get('guests');
        $statistic[0]['online_guests'] = $q_online_g->num_rows();
        $q_count_c = $this->db->get('forum_category');
        $statistic[0]['count_category'] = $q_count_c->num_rows();
        $q_count_s = $this->db->get('forum_subcategory');
        $statistic[0]['count_subcategory'] = $q_count_s->num_rows();
        $q_count_p = $this->db->get('forum_post');
        $statistic[0]['count_posts'] = $q_count_p->num_rows();
        $q_count_m = $this->db->get('forum_message');
        $statistic[0]['count_messages'] = $q_count_m->num_rows();
        $q_count_u = $this->db->get('users');
        $statistic[0]['count_users'] = $q_count_u->num_rows();
        
        $forum = array();$i = 0;
        $q_category = $this->db->get('forum_category');
        $r_category = $q_category->result_array();
        if($r_category)
        foreach($r_category as $key => $value){
            $forum[$i]['id_category'] = $value['id'];
            $forum[$i]['name_category'] = $value['title'];
            $this->db->where('category_id',$value['id']);
            $q_subcategory = $this->db->get('forum_subcategory');
            $r_subcategory = $q_subcategory->result_array();
            if($r_subcategory){
                $forum[$i]['list_subcategory'] = array();
                foreach($r_subcategory as $key2 => $value2){
                    $this->db->where('subcategory_id',$value2['id']);
                    $q_post = $this->db->get('forum_post');
                    $r_post = $q_post->row_array();
                    if($r_post){
                        $this->db->where('post_id',$r_post['id']);
                        $q_message = $this->db->get('forum_message');
                        $num_message = $q_message->num_rows();
                    } else {
                        $num_message = 0;
                    }
                    $has_last = array();
                    $hasnt_last = '';
                    if($value2['last_post_id'] == null){
                        $hasnt_last = 'Нет сообщений';
                    } else {
                        $has_last = array(array(1));
                    }
                    $forum[$i]['list_subcategory'][] = array(
                        'id_subcategory' => $value2['id'],
                        'name_subcategory' => $value2['title'],
                        'descr_subcategory' => $value2['short_info'],
                        'count_post' => $q_post->num_rows(),
                        'count_message' => $num_message,
                        'has_last' => $has_last,
                        'hasnt_last' => $hasnt_last,
                        'last_message_login' => $value2['last_poster_login'],
                        'last_message_date' => $value2['last_post_date'],
                    );
                }
            } else {
                $forum[$i]['list_subcategory'] = array();
            }
            $i++;
        }
        $data_forum = array(
            'mod_on' => $mod_on,
            'statistic' => $statistic,
            'forum' => $forum,
        );
        $this->parser->parse('forum_index',$data_forum);
        $this->_footer();
    }
    function _manage($action){
        $title = "";
        if($action[0] == "add"){
            $title = "Добавить раздел";
        } else if($action[0] == "addSub"){
            $title = "Добавить категорию";
        } else if($action[0] == "edit"){
            if($action[1] == "c")
                $title = "Редактировать раздел";
            else 
                $title = "Редактировать категорию";
        } else if($action[0] == "delete"){
            if($action[1] == "c")
                $title = "Удалить раздел";
            else 
                $title = "Удалить категорию";
        }
        $data_header = array(
            'title' => $title,
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        if($action[0] == "add"){
            $rules = array(
                array(
                        'field' => 'title',
                        'label' => 'Заголовок',
                        'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                $data_forum = array();
                $this->parser->parse('forum_c_add',$data_forum);
            } else {
                $user_id = $this->session->userdata('id');
                $login = $this->session->userdata('login');
        		$this->forum_model->addCategory($user_id,$login);
                redirect('/forum');
            }
        } else if($action[0] == "addSub"){
            $rules = array(
                array(
                        'field' => 'title',
                        'label' => 'Заголовок',
                        'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                        'field' => 'short_info',
                        'label' => 'Короткую информацию',
                        'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                $q_cat_list = $this->db->get('forum_category');
                $data_forum = array(
                    'category_list' => $q_cat_list->result_array(),
                );
                $this->parser->parse('forum_s_add',$data_forum);
            } else {
                $user_id = $this->session->userdata('id');
                $login = $this->session->userdata('login');
        		$this->forum_model->addSubcategory($user_id,$login);
                redirect('/forum');
            }
        } else if($action[0] == "edit"){
            if($action[1] == "c")
                $rules = array(
                    array(
                            'field' => 'title',
                            'label' => 'Заголовок',
                            'rules' => 'trim|required|min_length[3]|max_length[255]',
                    ),
                );
            else 
                $rules = array(
                    array(
                            'field' => 'title',
                            'label' => 'Заголовок',
                            'rules' => 'trim|required|min_length[3]|max_length[255]',
                    ),
                    array(
                            'field' => 'short_info',
                            'label' => 'Короткую информацию',
                            'rules' => 'trim|required|min_length[3]|max_length[255]',
                    ),
                );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                if($action[1] == "c"){
                    $this->db->where('id',$action[2]);
                    $q_cat_list = $this->db->get('forum_category');
                    $data_forum = array(
                        'category_list' => $q_cat_list->result_array(),
                    );
                    $this->parser->parse('forum_c_edit',$data_forum);
                } else {
                    $q_cat_list = $this->db->get('forum_category');
                    $r_cat_list = $q_cat_list->result_array();
                    $category_list = array();$i = 1;
                    foreach($r_cat_list as $key => $value){
                        $category_list[$i] = $value['title'];
                        $i++;
                    }
                    $this->db->where('id',$action[2]);
                    $q_s_list = $this->db->get('forum_subcategory');
                    $r_s_list = $q_s_list->result_array();
                    $data_forum = array(
                        'subcategory_list' => $q_s_list->result_array(),
                        'category_list' => form_dropdown('category_id', $category_list, $r_s_list[0]['category_id']),
                    );
                    $this->parser->parse('forum_s_edit',$data_forum);
                }
            } else {
                if($action[1] == "c"){
                    $this->forum_model->editCategory($action[2]);
                } else {
                    $this->forum_model->editSubcategory($action[2]);
                }
                redirect('/forum');
            }
        } else {
            $rules = array(
                array(
                        'field' => 'rem',
                        'label' => '',
                        'rules' => '',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                if($action[1] == "c"){
                    $data_forum = array();
                    $this->parser->parse('forum_c_delete',$data_forum);
                } else {
                    $data_forum = array();
                    $this->parser->parse('forum_s_delete',$data_forum);
                }
            } else {
                if($action[1] == "c"){
                    $this->forum_model->deleteCategory($action[2]);
                } else {
                    $this->forum_model->deleteSubcategory($action[2]);
                }
                //redirect('/forum');
            }
        }
        $this->_footer();
    }
    function _view($action){
        $title = "";
        $this->db->where('id',$action[1]);
        if($action[0] == "c"){
            $q_title = $this->db->get('forum_category');
            $r_title = $q_title->row_array($action[1]);
            if($r_title)
            $title = "Раздел - ".$r_title['title'];
        } else if($action[0] == "s"){
            $q_title = $this->db->get('forum_subcategory');
            $r_title = $q_title->row_array($action[1]);
            if($r_title)
            $title = "Категория - ".$r_title['title'];
        } else if($action[0] == "p"){
            $q_title = $this->db->get('forum_post');
            $r_title = $q_title->row_array($action[1]);
            if($r_title)
            $title = "Пост - ".$r_title['title'];
        }
        $data_header = array(
            'title' => $title,
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $mod_on = array();
        $statistic = array();
        $this->db->where('user_online',1);
        $q_online_u = $this->db->get('users');
        $statistic[0]['online_user'] = $q_online_u->num_rows();
        $this->load->helper('date');
        $time = now() - 300;
        $this->db->where('guest_date > ', gmt_to_local($time, 'UP6', FALSE));
        $q_online_g = $this->db->get('guests');
        $statistic[0]['online_guests'] = $q_online_g->num_rows();
        $q_count_c = $this->db->get('forum_category');
        $statistic[0]['count_category'] = $q_count_c->num_rows();
        $q_count_s = $this->db->get('forum_subcategory');
        $statistic[0]['count_subcategory'] = $q_count_s->num_rows();
        $q_count_p = $this->db->get('forum_post');
        $statistic[0]['count_posts'] = $q_count_p->num_rows();
        $q_count_m = $this->db->get('forum_message');
        $statistic[0]['count_messages'] = $q_count_m->num_rows();
        $q_count_u = $this->db->get('users');
        $statistic[0]['count_users'] = $q_count_u->num_rows();
        if($action[0] == "c"){
            $forum = array();$i = 0;
            $this->db->where('id',$action[1]);
            $q_category = $this->db->get('forum_category');
            $r_category = $q_category->row_array();
            if($r_category){
                $forum[$i]['name_category'] = $r_category['title'];
                $this->db->where('category_id',$r_category['id']);
                $q_subcategory = $this->db->get('forum_subcategory');
                $r_subcategory = $q_subcategory->result_array();
                if($r_subcategory){
                    $forum[$i]['list_subcategory'] = array();
                    foreach($r_subcategory as $key2 => $value2){
                        $this->db->where('subcategory_id',$value2['id']);
                        $q_post = $this->db->get('forum_post');
                        $r_post = $q_post->row_array();
                        if($r_post){
                            $this->db->where('post_id',$r_post['id']);
                            $q_message = $this->db->get('forum_message');
                            $num_message = $q_message->num_rows();
                        } else {
                            $num_message = 0;
                        }
                        $has_last = array();
                        $hasnt_last = '';
                        if($value2['last_post_id'] == null){
                            $hasnt_last = 'Нет сообщений';
                        } else {
                            $has_last = array(array(1));
                        }
                        $forum[$i]['list_subcategory'][] = array(
                            'id_subcategory' => $value2['id'],
                            'name_subcategory' => $value2['title'],
                            'descr_subcategory' => $value2['short_info'],
                            'count_post' => $q_post->num_rows(),
                            'count_message' => $num_message,
                            'has_last' => $has_last,
                            'hasnt_last' => $hasnt_last,
                            'last_message_login' => $value2['last_poster_login'],
                            'last_message_date' => $value2['last_post_date'],
                        );
                    }
                } else {
                    $forum[$i]['list_subcategory'] = array();
                }
            }
            $data_forum = array(
                'mod_on' => $mod_on,
                'statistic' => $statistic,
                'forum' => $forum,
            );
            $this->parser->parse('forum_c_view',$data_forum);
        } else if($action[0] == "s"){
            if($this->settings_model->user_auth())
                $mod_on = array(array(1));
            $forum = array();$i = 0;
            $this->db->where('id',$action[1]);
            $q_subcategory = $this->db->get('forum_subcategory');
            $r_subcategory = $q_subcategory->row_array();
            if($r_subcategory){
                $forum[$i]['name_subcategory'] = $r_subcategory['title'];
                $this->db->where('subcategory_id',$r_subcategory['id']);
                $this->db->order_by('id','DESC');
                $q_post2 = $this->db->get('forum_post');
                $r_post2 = $q_post2->result_array();
                if($r_post2){
                    $this->load->library('pagination');
                    $config['base_url'] = 'http://napulse.kz/forum/view/s/'.$action[1].'/page/';
                    $config['total_rows'] = $q_post2->num_rows();
                    $config['uri_segment'] = 6;
                    $config['per_page'] = '20';
                    $this->pagination->initialize($config);
                    $this->db->where('subcategory_id',$r_subcategory['id']);
                    $this->db->order_by('id','DESC');
                    $this->db->limit($config['per_page'], $action[3]);
                    $q_post = $this->db->get('forum_post');
                    $r_post = $q_post->result_array();
                    $forum[$i]['list_post'] = array();
                    foreach($r_post as $key2 => $value2){
                        $has_last = array();$hasnt_last = '';
                        if($value2['last_post_id'] == null){
                            $hasnt_last = 'Нет сообщений';
                        } else {
                            $has_last = array(array(1));
                        }
                        $this->db->where('post_id',$value2['id']);
                        $q_message = $this->db->get('forum_message');
                        $forum[$i]['list_post'][] = array(
                            'id_post' => $value2['id'],
                            'count_message' => $q_message->num_rows(),
                            'count_review' => $value2['review'],
                            'name_post' => $value2['title'],
                            'post_created_login' => $value2['user_login'],
                            'post_created_date' => $value2['date_posted'],
                            'has_last' => $has_last,
                            'hasnt_last' => $hasnt_last,
                            'last_message_login' => $value2['last_poster_login'],
                            'last_message_date' => $value2['last_post_date'],
                        );
                    }
                } else {
                    $forum[$i]['list_post'] = array();
                }
            }
            $data_forum = array(
                'mod_on' => $mod_on,
                'statistic' => $statistic,
                'forum' => $forum,
                'pagination' => $this->pagination->create_links(),
            );
            $this->parser->parse('forum_s_view',$data_forum);
        } else {
            if($this->settings_model->user_auth())
                $mod_on = array(array(1));
            $this->load->helper('html');
            $this->db->where('id',$action[1]);
            $q_review = $this->db->get('forum_post');
            $r_review = $q_review->row_array();
            $count_review = $r_review['review'] + 1;
            $data_review = array(
                'review' => $count_review,
            );
            $this->db->where('id',$action[1]);
            $this->db->update('forum_post',$data_review);
            $forum = array();$i = 0;
            $this->db->where('post_id',$action[1]);
            $this->db->order_by('id','ASC');
            $q_message2 = $this->db->get('forum_message');
            $r_message2 = $q_message2->result_array();
            $this->load->library('pagination');
            $config['base_url'] = 'http://napulse.kz/forum/view/p/'.$action[1].'/page/';
            $config['total_rows'] = $q_message2->num_rows();
            $config['uri_segment'] = 6;
            $config['per_page'] = '25';
            $this->pagination->initialize($config);
            $this->db->where('post_id',$action[1]);
            $this->db->order_by('id','ASC');
            $this->db->limit($config['per_page'], $action[3]);
            $q_message = $this->db->get('forum_message');
            $r_message = $q_message->result_array();
            foreach($r_message as $key => $value){
                $reply = '';$own_msg = '';
                $this->db->where('user_login',$value['user_login']);
                $q_info = $this->db->get('users');
                $r_info = $q_info->row_array();
                if($value['request_id'] != null)
                    $reply .= '.&nbsp;&nbsp;&nbsp;Ответу: <a href="#msg'.$value['request_id'].' ">#'.$value['request_id'].'</a>';
                if(($value['user_login'] == $this->session->userdata('login')) || $this->settings_model->user_admin())
                        $own_msg = '<a href="/forum/posting/edit/m/'.$value['id'].'">Редактировать</a>'.nbs(4).'<a href="/forum/posting/delete/m/'.$value['id'].'">Удалить</a>'.nbs(4);
                $forum[$i] = array(
                    'msg_id' => $value['id'],
                    'user_login' => $value['user_login'],
                    'subject' => $value['subject'],
                    'date' => $value['date_writed'],
                    'user_type' => $r_info['user_type'],
                    'has_reply' => $reply,
                    'own_msg' => $own_msg,
                    'user_count_post' => $r_info['user_c_f_post'],
                    'user_count_msg' => $r_info['user_c_f_msg'],
                );
                $i++;
            }            
            $data_forum = array(
                'mod_on' => $mod_on,
                'post_id' => $action[1],
                'statistic' => $statistic,
                'forum' => $forum,
                'pagination' => $this->pagination->create_links(),
            );
            $this->parser->parse('forum_p_view',$data_forum);
        }
        $this->_footer();
    }
    function _posting($action) {
        $title = "";
        if($action[0] == "post"){
            $title = "Добавить тему";
        } else if($action[0] == "edit"){
            if($action[1] == "p")
                $title = "Редактировать - пост";
            else 
                $title = "Редактировать - сообщение";
        } else if($action[0] == "delete"){
            if($action[1] == "p")
                $title = "Удалить - пост";
            else 
                $title = "Удалить - сообщение";
        } else if($action[0] == "reply"){
            $title = "Ответить";
        }
        $data_header = array(
            'title' => $title,
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        if($action[0] == "post"){
            $rules = array(
                array(
                        'field' => 'title',
                        'label' => 'Заголовок',
                        'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                        'field' => 'content',
                        'label' => 'Сообщение',
                        'rules' => 'trim|required',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                $q_category = $this->db->get('forum_category');
                $q_subcategory = $this->db->get('forum_subcategory');
                $data_forum = array(
                    'q_category' => $q_category->result_array(),
                    'q_subcaterogy' => $q_subcategory->result_array(),
                );
                $this->parser->parse('forum_p_add',$data_forum);
            } else {
                $user_id = $this->session->userdata('id');
                $login = $this->session->userdata('login');
        		$this->forum_model->addPost($user_id,$login);
                $subcategory_id = $this->input->post('subcategory_id');
                $subcategory_id = $this->checker->tsh($subcategory_id);
                redirect('/forum/view/s/'.$subcategory_id);
            }
        } else if($action[0] == "reply"){
            $rules = array(
                array(
                        'field' => 'subject',
                        'label' => 'Сообщение',
                        'rules' => 'trim|required',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                $this->load->helper('html');
                $forum = array();$i = 0;
                $this->db->where('post_id',$action[2]);
                $this->db->order_by('id','DESC');
                $this->db->limit(5);
                $q_message = $this->db->get('forum_message');
                $r_message = $q_message->result_array();
                foreach($r_message as $key => $value){
                    $reply = '';$own_msg = '';
                    $this->db->where('user_login',$value['user_login']);
                    $q_info = $this->db->get('users');
                    $r_info = $q_info->row_array();
                    if($value['request_id'] != null)
                        $reply .= '.&nbsp;&nbsp;&nbsp;Ответу: <a href="#msg'.$value['request_id'].' ">#'.$value['request_id'].'</a>';
                    if(($value['user_login'] == $this->session->userdata('login')) || $this->settings_model->user_admin())
                        $own_msg = '<a href="/forum/posting/edit/m/'.$value['id'].'">Редактировать</a>'.nbs(4).'<a href="/forum/posting/delete/m/'.$value['id'].'">Удалить</a>'.nbs(4);
                    $forum[$i] = array(
                        'msg_id' => $value['id'],
                        'user_login' => $value['user_login'],
                        'subject' => $value['subject'],
                        'date' => $value['date_writed'],
                        'user_type' => $r_info['user_type'],
                        'has_reply' => $reply,
                        'own_msg' => $own_msg,
                        'user_count_post' => $r_info['user_c_f_post'],
                        'user_count_msg' => $r_info['user_c_f_msg'],
                    );$i++;
                }            
                $data_forum = array(
                    'forum' => $forum,
                );
                $this->parser->parse('forum_m_add',$data_forum);
            } else {
                $user_id = $this->session->userdata('id');
                $login = $this->session->userdata('login');
                if (!isset($action[4]))
                    $action[4] = 0;
        		$this->forum_model->addComment($user_id,$login,$action[2],$action[4]);
                redirect('/forum/view/p/'.$action[2]);
            }
        } else if($action[0] == "edit"){
            $this->db->where('id',$action[2]);
            if($action[1] == "p"){
                $q_p = $this->db->get('forum_post');
                $r_p = $q_p->row_array();
                if(($r_p['user_login'] != $this->session->userdata('login')) && !$this->settings_model->user_admin())
                    show_404();
                $rules = array(
                    array(
                        'field' => 'title',
                        'label' => 'Заголовок',
                        'rules' => 'trim|required|min_length[3]|max_length[255]',
                    ),
                );
            } else {
                $q_m = $this->db->get('forum_message');
                $r_m = $q_m->row_array();
                if(($r_m['user_login'] != $this->session->userdata('login')) && !$this->settings_model->user_admin())
                   show_404();
                $rules = array(
                    array(
                        'field' => 'subject',
                        'label' => 'Сообщение',
                        'rules' => 'trim|required',
                    ),
                );
            }
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                if($action[1] == "p"){
                    $category_list = array();$subcategory_list =array();
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_post');
                    $r_post = $q_post->row_array();$i = 1;
                    $q_category_list = $this->db->get('forum_category');
                    $r_category_list = $q_category_list->result_array();
                    foreach($r_category_list as $key => $value){
                        $category_list[$i] = $value['title'];
                        $i++;
                    }$i = 1;
                    $q_subcategory_list = $this->db->get('forum_subcategory');
                    $r_subcategory_list = $q_subcategory_list->result_array();
                    foreach($r_subcategory_list as $key => $value){
                        $subcategory_list[$i] = $value['title'];
                        $i++;
                    }
                    $data_forum = array(
                        'info_post' => $q_post->result_array(),
                        'category_list' => form_dropdown('category_id', $category_list, $r_post['category_id']),
                        'subcategory_list' => form_dropdown('subcategory_id', $subcategory_list, $r_post['subcategory_id']),
                    );
                    $this->parser->parse('forum_p_edit',$data_forum);
                } else {
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_message');
                    $data_forum = array(
                        'info_post' => $q_post->result_array(),
                    );
                    $this->parser->parse('forum_m_edit',$data_forum);
                }
            } else {
                $user_id = $this->session->userdata('id');
                $login = $this->session->userdata('login');
                if($action[1] == "p"){
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_post');
                    $r_post = $q_post->row_array();
            		$this->forum_model->editPost($action[2]);
                    redirect('/forum/view/s/'.$r_post['subcategory_id']);
                } else {
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_message');
                    $r_post = $q_post->row_array();
            		$this->forum_model->editMessage($action[2]);
                    redirect('/forum/view/p/'.$r_post['post_id']);
                }
            }
        } else {
            $this->db->where('id',$action[2]);
            if($action[1] == "p"){
                $q_p = $this->db->get('forum_post');
                $r_p = $q_p->row_array();
                if(($r_p['user_login'] != $this->session->userdata('login')) && !$this->settings_model->user_admin())
                    show_404();
            } else {
                $q_m = $this->db->get('forum_message');
                $r_m = $q_m->row_array();
                if(($r_m['user_login'] != $this->session->userdata('login')) && !$this->settings_model->user_admin())
                   show_404();
            }
            $rules = array(
                array(
                    'field' => 'rem',
                    'rules' => '',
                ),
            );
            $this->form_validation->set_rules($rules);
            if($this->form_validation->run() == FALSE){
                if($action[1] == "p"){
                    $data_forum = array();
                    $this->parser->parse('forum_p_delete',$data_forum);
                } else {
                    $data_forum = array();
                    $this->parser->parse('forum_m_delete',$data_forum);
                }
            } else {
                if($action[1] == "p"){
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_post');
                    $r_post = $q_post->row_array();
            		$this->forum_model->deletePost($action[2]);
                    redirect('/forum/view/s/'.$r_post['subcategory_id']);
                } else {
                    $this->db->where('id',$action[2]);
                    $q_post = $this->db->get('forum_message');
                    $r_post = $q_post->row_array();
            		$this->forum_model->deleteMessage($action[2]);
                    redirect('/forum/view/p/'.$r_post['post_id']);
                }
            }
        }
        $this->_footer();
    }
    function _search($page,$search,$author = '',$type = 'msg'){
        $data_header = array(
            'title' => 'Поиск - '.$search,
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $this->db->order_by('id','DESC');
        $this->db->like('subject', $search);
        if($author != '')
            $this->db->like('user_login', $author);
        $q2_search = $this->db->get('forum_message');
        $q_c_search = $this->db->get('forum_message');
        $r2_search = $q2_search->result_array();
        $this->load->library('pagination');
        $config['base_url'] = 'http://napulse.kz/forum/search/?q='.$search.'&author='.$author.'&type=msg';
        $config['total_rows'] = $q2_search->num_rows();
        $config['uri_segment'] = 3;
        $config['per_page'] = '1';
        $config['page_query_string'] = TRUE;
        if($type == "msg"){
            $this->pagination->initialize($config);
        }
        $this->db->order_by('id','DESC');
        $this->db->limit($config['per_page'], $page);
        $this->db->like('subject', $search);
        if($author != '')
            $this->db->like('user_login', $author);
        $q_search = $this->db->get('forum_message');
        $r_search = $q_search->result_array();
        /*
        $this->db->like('title', $search);
        if($author != '')
            $this->db->like('user_login', $author);
        $q_search2 = $this->db->get('forum_post');
        $r_search2 = $q_search2->result_array();
        */
        $forum = array();$i = 0;
        if($type == 'msg'){
            $msg_cheked = TRUE;
            $post_cheked = FALSE;
            foreach($r_search as $key => $value){
                $reply = '';
                $this->db->where('user_id',$value['user_id']);
                $q_info_user = $this->db->get('users');
                $r_info_user = $q_info_user->row_array();
                if($value['request_id'] != null)
                    $reply .= '.&nbsp;&nbsp;&nbsp;Ответу: <a href="#msg'.$value['request_id'].' ">#'.$value['request_id'].'</a>';
                $forum[$i] = array(
                    'id' => $value['id'],
                    'user_login' => $value['user_login'],
                    'user_type' => $r_info_user['user_type'],
                    'user_count_post' => $r_info_user['user_c_f_post'],
                    'user_count_msg' => $r_info_user['user_c_f_msg'],
                    'subject' => $value['subject'],
                    'date_writed' => $value['date_writed'],
                    'has_reply' => $reply,
                );$i++;
            }
        } else {
            $msg_cheked = FALSE;
            $post_cheked = TRUE;
            foreach($r_search as $key => $value){
                $this->db->where('id',$value['post_id']);
                $q_info_user = $this->db->get('forum_post');
                $r_info_user = $q_info_user->row_array();
                $has_last = array();
                $hasnt_last = '';
                if($r_info_user['last_post_id'] == null){
                    $hasnt_last = 'Нет сообщений';
                } else {
                    $has_last = array(array(1));
                }
                $forum[$i] = array(
                    'id_post' => $r_info_user['id'],
                    'name_subcategory' => $r_info_user['title'],
                    'post_created_login' => $r_info_user['user_login'],
                    'post_created_date' => $r_info_user['date_posted'],
                    'count_message' => $q_c_search->num_rows(),
                    'count_review' => $r_info_user['review'],
                    'has_last' => $has_last,
                    'last_message_login' => $r_info_user['last_poster_login'],
                    'last_message_date' => $r_info_user['last_post_date'],
                    'hasnt_last' => $hasnt_last,
                );$i++;
            }
        }
        $data_forum = array(
            'q_search' => $search,
            'q_author' => $author,
            'pagination' => $this->pagination->create_links(),
            'radio_type' => form_radio('type', 'msg' , $msg_cheked)."Сообщения &nbsp;".form_radio('type', 'post' , $post_cheked)."Темы",
        );
        $data_forum['forum_post'] = array();
        if($type == 'post'){
            $data_forum['forum_msg'] = array();
            if(!empty($forum))
                $data_forum['forum_post'] = array(array(1));
            $data_forum['forum_list'] = $forum;
        } else {
            $data_forum['forum_msg'] = $forum;
        }
        $this->parser->parse('forum_search',$data_forum);
        $this->_footer();
    }
    function _include(){
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);           
        /*** Include content ***/
        
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_forum_active' => "background:url('".base_url()."img/link/own_profile_link-right.png') no-repeat right,url('".base_url()."img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>