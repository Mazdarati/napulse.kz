<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
        1 - Сообщения(входяшие,исходящие)
        2 - Просмотр профиля
        3 - Сообщения на форуме(после того как на форум доделается)
        4 - Изменять типы пользователей
*/
class User extends CI_Controller {
    public function __construct(){
        parent::__construct();
    }
    function _remap($user_login,$action){
        if(!$this->settings_model->user_auth()){
            redirect('/');
            exit(1);
        }
        $user_login = $this->checker->tsh($user_login);
        $this->db->where('user_login',$user_login);
        $q_has = $this->db->get('users');
        $r_has = $q_has->result_array();
        if($user_login == 'index' || !count($action)){
            $user_login = $this->session->userdata('login');
            redirect('/user/'.$user_login.'/show');
        }
        if ($action[0] == "editProfile"){
            if($this->checker->equalLogin($user_login,$this->session->userdata('login')) || $this->settings_model->user_admin())
                $this->_editProfile($user_login);
            else 
                redirect('/user/'.$this->session->userdata('login').'/show');
        } else if ($action[0] == "editPassword"){
            if($this->checker->equalLogin($user_login,$this->session->userdata('login')) || $this->settings_model->user_admin())
                $this->_editPassword($user_login);
            else 
                redirect('/user/'.$this->session->userdata('login').'/show');
        } else if ($action[0] == "editEmail"){
            if($this->checker->equalLogin($user_login,$this->session->userdata('login')) || $this->settings_model->user_admin())    
                $this->_editEmail($user_login);
            else 
                redirect('/user/'.$this->session->userdata('login').'/show');
        } else if ($action[0] == "sendMessage" && $r_has){
            if(!$this->checker->equalLogin($user_login,$this->session->userdata('login')))
                $this->_sendMessage($user_login);
            else 
                redirect('/user/'.$this->session->userdata('login').'/show');
        } else if ($action[0] == "ban"){
            if($this->settings_model->user_admin() && !$this->checker->equalLogin($user_login,$this->session->userdata('login')))
                $this->_ban($user_login);
            else 
                show_404();
        } else if ($action[0] == "remove"){
            if($this->settings_model->user_admin() && !$this->checker->equalLogin($user_login,$this->session->userdata('login')))
                $this->_remove($user_login);
            else 
                show_404();
        } else if ($action[0] == "show" && $r_has) {
            $this->_show($user_login);
        } else {
            show_404();
        }
    }
    function _show($user_login){
        $data_header = array(
            'title' => 'Страница пользователя -'.$user_login,
        );      
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        $this->db->where('user_login',$user_login);      
        $query_profile = $this->db->get('users');
        $result_profile = $query_profile->row_array();
        if($result_profile['user_online'] == 1){
            $user_status = 'Онлайн';
        } else {
            $user_status = 'Оффлайн';
        }
        $this->db->where('user_login',$user_login);
        $query_comment = $this->db->get('comments');
        $count_comments = $query_comment->num_rows();
        $this->db->where('user_login',$user_login);
        $query_blog = $this->db->get('blog');
        $count_blogs = $query_blog->num_rows();
        $has_blogs = array(array(),);
        $has_comments = array(array(),);
        $has_bc = array(array('has' => true,),);
        if($query_blog->num_rows() > 0)
            $has_blogs = $has_bc;
        else if($query_blog->num_rows() == 0)
            $count_blogs = 'отсутствуют';
        if($query_comment->num_rows() > 0)
            $has_comments = $has_bc;
        else if($query_comment->num_rows() == 0)
            $count_comments = 'отсутствуют';
        $data_profile = array(
            'profile' => $query_profile->result_array(),
            'comments' => $query_comment->result_array(),
            'blogs' => $query_blog->result_array(),
            'count_blogs' => $count_blogs,
            'count_comments' => $count_comments,
            'has_blogs' => $has_blogs,
            'has_comments' => $has_comments,
            'user_status' => $user_status,
        );
        $data = $this->parser->parse('site_profile',$data_profile);
        $this->_footer();
    }
    function _editProfile($user_login){
        $rules = array(
            array(
                    'field' => 'surname',
                    'label' => 'Фамилию',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'username',
                    'label' => 'Имя',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'patronymic',
                    'label' => 'Отчество',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'town',
                    'label' => 'Город',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение профиля -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $day = idate('d', strtotime($result_profile['user_birthday']));
            $month = idate('m', strtotime($result_profile['user_birthday']));
            $year = idate('Y', strtotime($result_profile['user_birthday']));
            $this->load->library('bdate');
            $date_day = $this->bdate->day();
            $date_month = $this->bdate->month();
            $date_year = $this->bdate->year();
            if($result_profile['user_gender'] == 1){
                $male_cheked = TRUE;
                $female_cheked = FALSE;
            } else {
                $male_cheked = FALSE;
                $female_cheked = TRUE;
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
                'birthday_day' => form_dropdown('day_of_birthday', $date_day, $day),
                'birthday_month' => form_dropdown('month_of_birthday', $date_month, $month),
                'birthday_year' => form_dropdown('year_of_birthday', $date_year, $year),
                'gender_radio' => form_radio('gender', 1, $male_cheked)."Мужской &nbsp;".form_radio('gender', 2, $female_cheked)."Женский",
            );
            $data = $this->parser->parse('site_profile_change',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->editProfile($user_login);
            redirect('/user/'.$user_login.'/show');
        }
    }
    function _editPassword($user_login){
        $rules = array(
            array(
                    'field' => 'cur_password',
                    'label' => 'Текущий пароль',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'new_password',
                    'label' => 'Новый пароль',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'confirm_password',
                    'label' => 'Потверждение',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение пароля -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
            );
            $data = $this->parser->parse('site_profile_password',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->editPassword($user_login);
            redirect('/user/'.$user_login.'/show');
        }
    }
    function _editEmail($user_login){
        $rules = array(
            array(
                    'field' => 'cur_email',
                    'label' => 'Текущий e-mail',
                    'rules' => 'trim|required|min_length[3]|max_length[255]|valid_email',
            ),
            array(
                    'field' => 'new_email',
                    'label' => 'Новый e-mail',
                    'rules' => 'trim|required|min_length[3]|max_length[255]|valid_email',
            ),
            array(
                    'field' => 'confirm_email',
                    'label' => 'Потверждение',
                    'rules' => 'trim|required|min_length[3]|max_length[255]|valid_email',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение e-mail -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
            );
            $data = $this->parser->parse('site_profile_email',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->editEmail($user_login);
            //mail
            redirect('/user/'.$user_login.'/show');
        }
    }
    function _sendMessage($user_login){
        $rules = array(
            array(
                    'field' => 'theme',
                    'label' => 'Тему',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
            ),
            array(
                    'field' => 'content',
                    'label' => 'Содержание',
                    'rules' => 'trim|required|min_length[3]',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Написать сообщение -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
            );
            $data = $this->parser->parse('site_user_message',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->sendMessage($user_login);
            redirect('/user/'.$user_login.'/show');
        }
    }
    function _ban($user_login){
        $rules = array(
            array(
                    'field' => 'day_of_ban',
                    'label' => 'День',
                    'rules' => 'required',
            ),
            array(
                    'field' => 'month_of_ban',
                    'label' => 'День',
                    'rules' => 'required',
            ),
            array(
                    'field' => 'year_of_ban',
                    'label' => 'День',
                    'rules' => 'required',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Забанить -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $date_now_day = date('d');
            $date_now_month = date('m');
            $date_now_year = date('Y');
            $this->load->library('bdate');
            $date_day = $this->bdate->day();
            $date_month = $this->bdate->month();
            $date_year = $this->bdate->year();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
                'ban_day' => form_dropdown('day_of_ban', $date_day,$date_now_day),
                'ban_month' => form_dropdown('month_of_ban', $date_month,$date_now_month),
                'ban_year' => form_dropdown('year_of_ban', $date_year,$date_now_year),
            );
            $data = $this->parser->parse('site_user_ban',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->banUser($user_login);
            redirect('/user/'.$user_login.'/show');
        }
    }
    function _remove($user_login){
        $rules = array(
            array(
                    'field' => 'remove',
                    'label' => 'Чекер',
                    'rules' => 'required',
            ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Удалить -'.$user_login,
            );      
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $this->db->where('user_login',$user_login);      
            $query_profile = $this->db->get('users');
            $result_profile = $query_profile->row_array();
            if($result_profile['user_online'] == 1){
                $user_status = 'Онлайн';
            } else {
                $user_status = 'Оффлайн';
            }
            $data_profile = array(
                'profile' => $query_profile->result_array(),
                'user_status' => $user_status,
            );
            $data = $this->parser->parse('site_user_remove',$data_profile);
            $this->_footer();
        } else {
            $this->load->model('user_model');      		    
    		$this->user_model->removeUser($user_login);
            redirect('/user/'.$this->session->userdata('login').'/show');
        }
    }
    function _include(){      
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        ); 
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array();
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}