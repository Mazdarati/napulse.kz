<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
        1 - Доступ админам 
            с) Удаление категории
            d) Удалении тэгов
            e) удаление коммента
            f) удаление записи в блоге
        2 - Общий доступ(собственных)
            a) удаление коммента
            b) удаление записи
*/
class Blog extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $this->_show_list(0);
    }
    public function page($num_page = 0){
        $num_page = $this->checker->tsh($num_page);
        if(!is_numeric($num_page)) unset($num_page);
        if(empty($num_page)){
            $num_page = 0;
        }
        $this->_show_list($num_page);
    }
    function _show_list($num_page){
        $data_header = array(
            'title' => 'Блогинг',
        );
        $this->parser->parse('site_header',$data_header);
        $this->_include();
        
        $this->load->library('pagination');
        $this->db->order_by('blog_id','desc');
        $query = $this->db->get('blog');
        $config['base_url'] = 'http://napulse.kz/blog/page/';
        $config['per_page'] = '5';
        $per_page = ($config['per_page']*1);
        $config['total_rows'] = $query->num_rows();
        $this->pagination->initialize($config);
        if($num_page == 0)
            $page_from = 0;
        else
            $page_from = $per_page*($num_page/$per_page);
        $page_to = $page_from + $per_page;
        $this->db->order_by('blog_id','desc');
        $this->db->limit($page_to, $page_from);
        $query_current = $this->db->get('blog');
        $query_list_category = $this->db->get('category');
        $query_list_cloud = $this->db->get('cloud');
        $data_blog = array(
            'blog_data' => $query_current->result_array(),
            'category_list' => $query_list_category->result_array(),
            'cloud_list' => $query_list_cloud->result_array(),
            'pagination' => $this->pagination->create_links(),
        );
        $this->parser->parse('site_blog',$data_blog);
        $this->_footer();
    }
    public function add(){
        if(!$this->settings_model->user_auth()){
            redirect('/blog');
            exit(1);
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Заголовок',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                    'field' => 'post_short_info',
                    'label' => 'Короткую информацию',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                    'field' => 'post_content',
                    'label' => 'Содержание',
                    'rules' => 'trim|required|min_length[15]',
                ),
                array(
                    'field' => 'post_category',
                    'label' => 'Категорию',
                    'rules' => 'required',
                ),
        );
        $query_list_category = $this->db->get('category');
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Добавление записи в блог',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array(
                'category_list' => $query_list_category->result_array(),
                'error' => '',
            );
            $this->parser->parse('site_blog_add',$data_blog);
            $this->_footer();
        } else {
            $config['upload_path'] = 'img/content/blog/';
      		$config['allowed_types'] = 'gif|jpg|png|jpeg';
      		$config['max_size']	= '300';
      		$config['max_width']  = '625';
      		$config['max_height']  = '250';
      		$this->load->library('upload', $config);
      		if ( ! $this->upload->do_upload()){
      		    $data_header = array(
                    'title' => 'Добавление записи в блог',
                );
                $this->parser->parse('site_header',$data_header);
                $this->_include();
     			$error = array('error' => $this->upload->display_errors(),'category_list' => $query_list_category->result_array(),);
     			$this->parser->parse('site_blog_add', $error);
                $this->_footer();
      		} else {
      		    $this->load->model('blog_model');      		    
     			$data = $this->upload->data();
                $file_name = $data['file_name'];
     			$this->blog_model->blog_add($file_name);
                redirect('/blog');
      		}
        }        
    }
    public function edit($id = ''){
        if(!$this->settings_model->user_auth()){
            redirect('/blog');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/blog');
        }
        $login = $this->session->userdata('login');
        $this->db->where('blog_id',$id);
        $this->db->where('user_login',$login);
        $query = $this->db->get('blog');
        if(!$query->row_array() || !$this->settings_model->user_admin()){
            redirect('/blog');
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Заголовок',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                    'field' => 'post_short_info',
                    'label' => 'Короткую информацию',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
                array(
                    'field' => 'post_content',
                    'label' => 'Содержание',
                    'rules' => 'trim|required|min_length[15]',
                ),
                array(
                    'field' => 'post_category',
                    'label' => 'Категорию',
                    'rules' => 'required',
                ),
        );
        $query_list_category = $this->db->get('category');
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение записи в блог',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array(
                'category_list' => $query_list_category->result_array(),
                'blog' => $query->result_array(),
                'error' => '',
            );
            $this->parser->parse('site_blog_edit',$data_blog);
            $this->_footer();
        } else {
            $config['upload_path'] = 'img/content/blog/';
      		$config['allowed_types'] = 'gif|jpg|png|jpeg';
      		$config['max_size']	= '300';
      		$config['max_width']  = '625';
      		$config['max_height']  = '250';
      		$this->load->library('upload', $config);
      		if ( ! $this->upload->do_upload()){
      		    $data_header = array(
                    'title' => 'Изменение записи в блог',
                );
                $this->parser->parse('site_header',$data_header);
                $this->_include();
     			$error = array('error' => $this->upload->display_errors(),'category_list' => $query_list_category->result_array(),
                'blog' => $query->result_array(),);
     			$this->parser->parse('site_blog_edit', $error);
                $this->_footer();
      		} else {
      		    $this->load->model('blog_model');      		    
     			$data = $this->upload->data();
                $file_name = $data['file_name'];
     			$this->blog_model->blog_edit($id,$file_name);
                redirect('/blog/view/'.$id);
      		}
        }
    }
    // remove post in blog
    public function editComment($id = ''){
        if(!$this->settings_model->user_auth()){
            redirect('/blog');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/blog');
        }
        $login = $this->session->userdata('login');
        $this->db->where('com_id',$id);
        $this->db->where('user_login',$login);
        $query_comment = $this->db->get('comments');
        if(!$query_comment->row_array() || !$this->settings_model->user_admin()){
            redirect('/blog');
        }
        $rules = array(
            array(
                'field' => 'post_content',
                'label' => 'содержание',
                'rules' => 'trim|required|min_length[3]',
            ),    
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение комментарии в посте',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $edit_com = array(
                array('on' => '1'),
            );
            $new_like = array(
                array('on' => '1',)
            );
            $result_comment = $query_comment->row_array();
            $this->db->where('blog_id',$result_comment['blog_id']);            
            $query = $this->db->get('blog');
            $this->db->where('blog_id',$result_comment['blog_id']);
            $q_com = $this->db->get('comments');
            $query_list_category = $this->db->get('category');
            $query_list_cloud = $this->db->get('cloud');
            $data_blog = array(
                'blog_data' => $query->result_array(),
                'comment_data' => $q_com->result_array(),
                'new_comment' => array(),
                'edit_comment' => $edit_com,
                'data_current_comment' => $query_comment->result_array(),
                'new_like' => $new_like,
                'category_list' => $query_list_category->result_array(),
                'cloud_list' => $query_list_cloud->result_array(),
            );
            $this->parser->parse('site_blog_show',$data_blog);
            $this->_footer();
        } else {
  		    $this->load->model('blog_model');      		    
 			$this->blog_model->comment_edit($id);
            redirect('/blog/view/'.$result_comment['blog_id']);
        }
    }
    // remove comment
    public function view($id = ''){
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/blog');
        }
        $this->db->where('blog_id',$id);
        $query = $this->db->get('blog');
        if(!$query->row_array()){
            redirect('/blog');
        }
        $this->db->where('blog_id',$id);
        $q_com = $this->db->get('comments');
        $r_com = $q_com->num_rows();
        if($this->settings_model->user_auth()){
            $new_com = array(
                array('on' => '1'),
            );
            $new_like = array(
                array('on' => '1',)
            );
        } else {
            $new_com = array();
            $new_like = array();
        }
        $rules = array(
            array(
                'field' => 'post_content',
                'label' => 'содержание',
                'rules' => 'trim|required|min_length[3]',
            ),    
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $result_title = $query->row_array();
            $title = $result_title['blog_title'];
            $data_header = array(
                'title' => $title,
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $query_list_category = $this->db->get('category');
            $query_list_cloud = $this->db->get('cloud');
            $data_blog = array(
                'blog_data' => $query->result_array(),
                'comment_data' => $q_com->result_array(),
                'new_comment' => $new_com,
                'edit_comment' => array(),
                'new_like' => $new_like,
                'data_current_comment' => array(),
                'category_list' => $query_list_category->result_array(),
                'cloud_list' => $query_list_cloud->result_array(),
            );
            $this->parser->parse('site_blog_show',$data_blog);
            $this->_footer();
        } else {
            $this->load->model('blog_model');
            $this->blog_model->comment_add($id);
            redirect('/blog/view/'.$id); 
        }
    }
    public function addCategory(){
        if(!$this->settings_model->user_admin()){
            redirect('/blog');
            exit(1);
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Добавление категории',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array();
            $this->parser->parse('site_category_add',$data_blog);
            $this->_footer();
        } else {
            $this->load->model('blog_model');      		    
 			$this->blog_model->category_add();
            redirect('/blog');
        }        
    }
    public function editCategory($id = ''){
        if(!$this->settings_model->user_admin()){
            redirect('/blog');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/blog');
        }
        $this->db->where('cat_id',$id);
        $query_category = $this->db->get('category');
        if(!$query_category->row_array()){
            redirect('/blog');
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение категории',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array(
                'category' => $query_category->result_array(),
            );
            $this->parser->parse('site_category_edit',$data_blog);
            $this->_footer();
        } else {
            $this->load->model('blog_model');      		    
 			$this->blog_model->category_edit($id);
            redirect('/blog');
        }        
    }
    // remove category
    public function addTags(){
        if(!$this->settings_model->user_admin()){
            redirect('/blog');
            exit(1);
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Добавление тэгов',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array();
            $this->parser->parse('site_tags_add',$data_blog);
            $this->_footer();
        } else {
            $this->load->model('blog_model');      		    
 			$this->blog_model->tags_add();
            redirect('/blog');
        }        
    }
    public function editTags($id = ''){
        if(!$this->settings_model->user_admin()){
            redirect('/blog');
            exit(1);
        }
        $id = $this->checker->tsh($id);
        if(!is_numeric($id)) unset($id);
        if(empty($id)){
            redirect('/blog');
        }
        $this->db->where('cloud_id',$id);
        $query_cloud = $this->db->get('cloud');
        if(!$query_cloud->row_array()){
            redirect('/blog');
        }
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => 'Название',
                    'rules' => 'trim|required|min_length[3]|max_length[255]',
                ),
        );
        $this->form_validation->set_rules($rules);
        if($this->form_validation->run() == FALSE){
            $data_header = array(
                'title' => 'Изменение тэга',
            );
            $this->parser->parse('site_header',$data_header);
            $this->_include();
            $data_blog = array(
                'tags' => $query_cloud->result_array(),
            );
            $this->parser->parse('site_tags_edit',$data_blog);
            $this->_footer();
        } else {
            $this->load->model('blog_model');      		    
 			$this->blog_model->tags_edit($id);
            redirect('/blog');
        }        
    }
    // remove tags
    function _include(){
        $data_load_css = array(
            'url_style' => base_url().'styles/common.css',
        );
        $this->parser->parse('site_load_css',$data_load_css);
        
        /*** Include Scripts ***/
        
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/jquery.min.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_load_scripts = array(
            'url_scripts' => base_url().'scripts/Sign.js',
        );
        $this->parser->parse('site_load_scripts',$data_load_scripts);
        $data_scripts_code = array(
            'scripts_code' => 'Sign();',
        );
        $this->parser->parse('site_scripts_code',$data_scripts_code);           
        /*** Include content ***/
        
        $data_content = array();
        $this->parser->parse('site_content',$data_content);
        $data_menu = array(
            'link_blog_active' => "background:url('".base_url()."img/link/own_profile_link-right.png') no-repeat right,url('".base_url()."img/link/own_profile_link-left.png') no-repeat left;",
        );
        $this->parser->parse('site_menu',$data_menu);
    }
    function _footer(){
        $data_footer = array();
        $this->parser->parse('site_footer',$data_footer);
    }
}
?>