<?php

/**
 * @author miracle
 * @copyright 2012
 */

if ( !defined('BASEPATH') ) exit('No direct script access allowed');

class bdate {
    
    function day(){
        $date_day = array();
        for($i = 31; $i > 0; $i--)
            $date_day[$i] = $i;
        return $date_day;
    }
    function month(){
        $date_month = array();
        $list_month = array(
            1 => 'Январь',
            2 => 'Февраль',
            3 => 'Март',
            4 => 'Апрель',
            5 => 'Май',
            6 => 'Июнь',
            7 => 'Июль',
            8 => 'Август',
            9 => 'Сентябрь',
            10 => 'Октябрь',
            11 => 'Ноябрь',
            12 => 'Декабрь',
        );
        for($i = 1; $i < 13; $i++)
            $date_month[$i] = $list_month[$i];
        return $date_month;
    }
    function year(){
        $date_year = array();
        for($i = date('Y'); $i > 1964; $i--)
            $date_year[$i] = $i;
        return $date_year;
    }
}

?>