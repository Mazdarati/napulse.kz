<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class checker {
    
    function tsh($data){
        $data = trim($data);
        $data = htmlspecialchars($data);
        $data = stripslashes($data);
        return $data;
    }
    
    function equalLogin($log,$log2){
        if($log == $log2){
            return true;
        } else {
            return false;
        }
    }
}

?>