<div class="sidebar">
    <? if($this->session->userdata('logged_in')): ?>
    <div style="padding-bottom: 15px;">
        <a href="/blog/add" style="padding: 5px 55px; background: #ddd;">Добавить Блог</a>
    </div>
    <? endif; ?>
    <div class="sidebar_title">Категории</div>
    <div class="sidebar_links">{category_list}<p><a href="">{cat_title}</a></p>{/category_list}</div>
    <div class="sidebar_title">Теги</div>
    <div id="blog_tags">{cloud_list}<a href="">{cloud_title}</a>,&nbsp;{/cloud_list}</div>
    <div class="sidebar_title">Последние комментарии</div>
    <div class="sidebar_links"></div>
    <div class="sidebar_title">Рейтинг блогов</div>
    <div class="sidebar_links"></div>
</div>