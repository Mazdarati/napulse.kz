<div id="content">
    Поиск в форуме:
    <form method="get">
        <table cellpadding="0" cellspacing="0">
            <tbody>
                <tr>
                    <td><b>Запрос : </b></td>
                    <td>&nbsp;&nbsp;<input type="text" name="q" value="{q_search}" /></td>
                </tr>
                <tr>
                    <td><b>Поиск по автору : </b></td>
                    <td>&nbsp;&nbsp;<input type="text" name="author" value="{q_author}" /></td>
                </tr>
                <tr>
                    <td><b>Показывать результаты : </b></td>
                    <td>&nbsp;&nbsp;&nbsp;{radio_type}</td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input type="submit" value="Искать" /></td>
                </tr>
            </tbody>
        </table>
    </form><br />
    {pagination}
    <div id="forum">
        {forum_msg}
        <table cellpadding="0" cellspacing="0" class="f_table_msg" id="msg{id}">
            <tbody>
                <tr>
                    <td class="td_info"><a href="/user/{user_login}/show">{user_login}</a><div style="float: right;">#{id}</div><br /><span class="f_user_type">{user_type}</span><br /><br /><span class="f_user_post">Постов: {user_count_post}<br />Сообщении: {user_count_msg}</span></td>
                    <td class="td_content">{subject}<br /><br /><div class="f_date">Добавлен: {date_writed}{has_reply}</div></td>
                </tr>
            </tbody>
        </table>
        {/forum_msg}
        {forum_post}
        <table cellpadding="0" cellspacing="0" class="f_table">
            <thead>
                <tr>
                    <th class="th_cat">Темы</th>
                    <th class="th_col">Сообщения</th>
                    <th class="th_col">Просмотры</th>
                    <th class="th_last">Последнее сообщение</th>
                </tr>
            </thead>
            <tbody>
                {forum_list}
                <tr>
                    <td class="td_margin_cat"><a href="/forum/view/p/{id_post}">{name_subcategory}</a><br /><span><a href="/user/{post_created_login}/show">{post_created_login}</a>&nbsp;{post_created_date}</span></td>
                    <td class="td_col">{count_message}</td>
                    <td class="td_col td_right_border">{count_review}</td>
                    <td class="td_last">{has_last}<a href="/user/{last_message_login}/show">{last_message_login}</a><br />{last_message_date}{/has_last}{hasnt_last}</td>
                </tr>
                {/forum_list}
            </tbody>
        </table>
        {/forum_post}
    </div>
</div>