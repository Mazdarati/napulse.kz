<div id="content">
    {mod_on}<div><a href="/forum/manage/add"><button class="add_cat_sub">Добавить раздел</button></a><a href="/forum/manage/addSub"><button class="add_cat_sub">Добавить категорию</button></a></div>{/mod_on}
    <div>
        {forum}
        <table cellpadding="0" cellspacing="0" class="f_table">
            <thead>
                <tr>
                    <th class="th_cat"><a href="/forum/view/c/{id_category}">{name_category}</a></th>
                    <th class="th_col">Темы</th>
                    <th class="th_col">Сообщения</th>
                    <th class="th_last">Последнее сообщение</th>
                </tr>
            </thead>
            <tbody>
                {list_subcategory}
                <tr>
                    <td class="td_margin_cat"><a href="/forum/view/s/{id_subcategory}">{name_subcategory}</a><br /><span>{descr_subcategory}</span></td>
                    <td class="td_col">{count_post}</td>
                    <td class="td_col td_right_border">{count_message}</td>
                    <td class="td_last">{has_last}<a href="/user/{last_message_login}/show">{last_message_login}</a><br />{last_message_date}{/has_last}{hasnt_last}</td>
                </tr>
                {/list_subcategory}
            </tbody>
        </table>
        {/forum}
    </div>
    {statistic}
    <div id="f_common">
        <div class="f_statistic"><tt>Статистика:</tt></div>
        <div class="f_info"><b>Онлайн</b>: пользователей: <b>{online_user}</b> ; гостей: <b>{online_guests}</b><br />Разделов : <b>{count_category}</b> | Категорий: <b>{count_subcategory}</b> |Сообщений: <b>{count_messages}</b> | Тем: <b>{count_posts}</b> | Пользователей: <b>{count_users}</b></div>
    </div>
    {/statistic}
</div>