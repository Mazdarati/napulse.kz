<div id="content">
    <?=$this->form_validation->error_string(); ?>
    <form method="post">
        <textarea name="subject"></textarea>
        <input type="submit" value="Написать" />
    </form>
    Обзор темы:
    <div id="forum">
        {forum}
        <table cellpadding="0" cellspacing="0" class="f_table_msg" id="post{post_id}">
            <tbody>
                <tr>
                    <td class="td_info"><a href="/user/{user_login}/show">{user_login}</a><div style="float: right;">#{msg_id}</div><br /><span class="f_user_type">{user_type}</span><br /><br /><span class="f_user_post">Постов: {user_count_post}<br />Сообщении: {user_count_msg}</span></td>
                    <td class="td_content">{subject}<br /><br /><div class="f_date">{own_msg}<a href="/forum/posting/reply/p/{post_id}/m/{msg_id}">Ответить</a><?=nbs(4);?>Добавлен: {date}{has_reply}</div></td>
                </tr>
            </tbody>
        </table>
        {/forum}
    </div>
</div>