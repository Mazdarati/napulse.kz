<script>
$('#close').click(function(){
    $('#sign_form').hide(400, function(){$('#sign_form').html("");});
    window.history.back();
});
</script>
<div id="sign_backgr">
    <form method="post" action="/signup">
        <table cellpadding="0" cellspacing="1" class="sign" id="signup">
            <tr>
                <td id="page_title" colspan="2">
                    <div id="close">CLOSE</div>
                    ПРИСОЕДИНЯЙТЕСЬ К НАМ!  
                </td>
            </tr>
            <tr>
                <td colspan="2" class="prescription">
                  Для создания аккаунта:
                </td>
            </tr>
            <tr>
                <td class="description" id="sign_des">
                    Введите данные
                    <?=$this->form_validation->error_string(); ?>
                </td>
                <td class="description" id="sign_des">
                    Введите символы с картинки
                </td>
            </tr>
            <tr>
                <td>
                    <table cellpadding="0" cellspacing="0" style="padding-bottom:10px;width:100%;">
                        <tr>
                            <td id="input_def">
                                Логин пользователя:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="login"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="input_def">
                                Пароль:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="password" name="password"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="input_def">
                                Повторите пароль:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="password" name="d_password"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="input_def">
                                Ваш Email:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="email"/>
                            </td>
                        </tr>
                    </table>
                </td>
                <td valign="top" style="padding-top:25px">
                    <div id="captcha">
                        <img src="code/my_codegen.php" height="70px" width="258px" />
                    </div>
                    <div id="captcha_set">
                        <a href="">Обновить символы</a>
                    </div>
                    <div id="input_def">
                        Для ввода символов:
                    </div>
                    <input type="text" name="captcha_code"/>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="description" style="font-size:10pt;">
                    Прочитайте <a href="">"Пользовательское соглашение"</a>
                </td>
            </tr>
            <tr>
                <td style="padding:10px 0px 10px 0px;">
                    <input type="submit" value="Зарегистрироваться"/>
                </td>
            </tr>
        </table>
    </form>
</div>