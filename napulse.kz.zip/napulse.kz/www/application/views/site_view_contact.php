<table cellpadding="5" cellspacing="2" style="padding-top:10px;width:100%;">
    <tr>
        <td id="contact_type">
            Номера телефонов:
        </td>
        <td id="contact_info">
            {numberphone}
        </td>                                
    </tr>
    <tr>
        <td id="contact_type">
            Факс:
        </td>
        <td id="contact_info">
            {fax}
        </td>
    </tr>
    <tr>
        <td id="contact_type">
            Email: 
        </td>
        <td id="contact_info">
            {email}
        </td>                                
    </tr>
    <tr>
        <td id="contact_type">
            Вконтакте:
        </td>
        <td id="contact_info">
            {vkontakte}
        </td>                                
    </tr>
    <tr>
        <td id="contact_type">
            Facebook:
        </td>
        <td id="contact_info">
            {facebook}
        </td>
    </tr>
    <tr>
        <td id="contact_type">
            Почтовый индекс:
        </td>
        <td id="contact_info">
            {postcode}
        </td>                                
    </tr>
    <tr>
        <td id="contact_type">
            Адрес:
        </td>
        <td id="contact_info">
            {address}
        </td>                                
    </tr>                                                           
</table>