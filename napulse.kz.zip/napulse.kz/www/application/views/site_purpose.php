<div id="content">
    <div id="page_title">
        Цель проекта
    </div>
</div>