<div id="content">
    <div id="page_title">
        Удалить спонсора
    </div>
    {partner}
    <p><b>Название:</b> {partner_title}</p>
    <p><b>Описание:</b> {partner_descr}</p>
    {/partner}
    <form method="post">
        <input type="hidden" name="remove" value="1" />
        <input type="submit" value="Удалить" />
    </form>
</div>