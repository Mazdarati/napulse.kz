<div id="content">
    <div id="page_title">
        Редактировать категорию
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        {category}
        <p>Заголовок: <input name="post_title" type="text" value="{cat_title}" /></p><br />
        {/category}
        <input type="submit" value="Редактировать" />
    </form>
</div>