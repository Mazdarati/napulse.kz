<div id="content">
    <table cellpadding="0" cellspacing="1" id="contact">
        <tr>
            <td colspan="2" id="page_title">
                Редактировать Контакты
            </td>
        </tr>
        <tr>
            <td>
                <form method="POST">
                    <table cellpadding="5" cellspacing="0" style="padding-top:10px;width:100%;">
                        <tr>
                            <td id="contact_msg_des">
                                Телефон:
                            </td>
                            <td style="width:75%;">
                                <input name="phone" type="text" style="width:85%;" value="{numberphone}"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Факс:
                            </td>
                            <td>
                                <input name="fax" type="text" style="width:85%;" value="{fax}"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Email:
                            </td>
                            <td>
                                <input name="email" type="text" style="width:85%;" value="{email}"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                VK:
                            </td>
                            <td>
                                <input name="vk" type="text" style="width:85%;" value="{vkontakte}"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Facebook:
                            </td>
                            <td>
                                <input name="facebook" type="text" style="width:85%;" value="{facebook}"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Почтовый индекс:
                            </td>
                            <td>
                                <input name="postcode" type="text" style="width:85%;" value="{postcode}"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Адрес:
                            </td>
                            <td>
                                <input name="address" type="text" style="width:85%;" value="{address}"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input name="contact_id" type="hidden" style="width:89%;" value="{id}"/>
                                <input type="submit" style="width:89%;" value="Сохранить"/>
                            </td>                                
                        </tr>                                                                                                                            
                    </table>
                </form>                            
            </td>
            <td valign="top">
                <?$this->view('site_view_contact');?>
            </td>
        </tr>
    </table>
</div>