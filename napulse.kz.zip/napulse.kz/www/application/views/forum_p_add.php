<div id="content">
    <div id="page_title">
        Добавить пост
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="title" type="text" /></p>
        <p>Сообщение: <textarea name="content"></textarea></p>
        <p>Раздел: <select name="category_id">{q_category}<option value="{id}">{title}</option>{/q_category}</select></p>
        <p>Категория: <select name="subcategory_id">{q_subcaterogy}<option value="{id}">{title}</option>{/q_subcaterogy}</select></p>
        <input type="submit" value="Добавить" />
    </form>
</div>