<div id="content">
    <div id="page_title">
        Редактировать пост
        <?=$this->form_validation->error_string(); ?>
    </div>
    {info_post}
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="title" type="text" value="{title}" /></p>
        <p>Раздел: {category_list}</p>
        <p>Категория: {subcategory_list}</p>
        <input type="submit" value="Редактировать" />
    </form>
    {/info_post}
</div>