<div id="content">
    <div id="page_title">
        Добавить пост
        <?=$this->form_validation->error_string(); ?>
        <?=$error;?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="post_title" type="text" /></p>
        <p>Короткая информация: <textarea name="post_short_info"></textarea></p>
        <p>Обложка: <input type="file" name="userfile" size="20" /></p>
        <p>Содержимое: <textarea name="post_content"></textarea></p>
        <p>Категория: <select name="post_category">{category_list}<option value="{cat_id}">{cat_title}</option>{/category_list}</select></p>
        <p>Теги: <textarea name="post_cloud"></textarea></p>
        <input type="submit" value="Добавить" />
    </form>
</div>