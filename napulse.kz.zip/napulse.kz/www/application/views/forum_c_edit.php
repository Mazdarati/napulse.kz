{category_list}
<div id="content">
    <div id="page_title">
        Редактировать раздел
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="title" type="text" value="{title}" /></p>
        <input type="submit" value="Редактировать" />
    </form>
</div>
{/category_list}