<div id="content">
    <div id="page_title">
       Настройки пользователя
    </div>
    {profile}
    <div class="user_info">
       <div class="user_photo"></div>
       <div id="user_name">{user_surname}&nbsp;{user_name}</div>
       <div id="user_desc">
          Логин: {user_login}<br/>
          Группа: {user_type}<br/>
          Статус: {user_status}
       </div>
    </div>
    <div id="user_info"  align="center">
        <?=$this->form_validation->error_string(); ?>
        <form method="post">
            <table cellpadding="0" cellspacing="0">
                <tbody>
                <tr>
                    <td>Фамилия :</td>
                    <td><input type="text" name="surname" value="{user_surname}" /></td>    
                </tr>
                <tr>
                    <td>Имя :</td>
                    <td><input type="text" name="username" value="{user_name}" /></td>    
                </tr>
                <tr>
                    <td>Отчество :</td>
                    <td><input type="text" name="patronymic" value="{user_patronymic}" /></td>    
                </tr>
                <tr>
                    <td>Пол :</td>
                    <td>{gender_radio}</td>    
                </tr>
                <tr>
                    <td>Дата рождения :</td>
                    <td>{birthday_day}&nbsp;{birthday_month}&nbsp;{birthday_year}</td>    
                </tr>
                <tr>
                    <td>Город :</td>
                    <td><input type="text" name="town" value="{user_town}" /></td>    
                </tr>
                <tr >
                    <td colspan="2" align="center"><br /><input type="submit" value="Сохранить" /></td>    
                </tr>
                </tbody>
            </table>
        {/profile}
        </form>
    </div>
</div>