<div id="content">
    <div id="page_title">
        БЛОГ САЙТА
    </div>
    <div id="blog">
        {pagination}
        {blog_data}
        <div id="post">
            <div id="post_image">
                <img src="{blog_photo}"/>
            </div>
            <div id="post_title">{blog_title}</div>
            <div id="post_text">{blog_short_info}</div>
            <div class="inform" id="post_info" >{blog_date_posted} | Добавил <a href="<?=base_url();?>user/{user_login}"><b>{user_login}</b></a>  | <a href="<?=base_url();?>blog/view/{blog_id}">Комментарии({blog_count_com})</a> | <a href="<?=base_url();?>blog/view/{blog_id}">Подробнее</a></div>
        </div>
        {/blog_data}
        {pagination}
    </div>
    <?php $this->view('site_sidebar');?>
</div>