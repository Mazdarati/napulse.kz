<div id="content">
    <div id="page_title">
       Страница пользователя
    </div>
    {profile}
    <div class="user_info">
       <div class="user_photo"></div>
       <div id="user_name">{user_surname}&nbsp;{user_name}</div>
       <div id="user_desc">
          Логин: {user_login}<br/>
          Группа: {user_type}<br/>
          Статус: {user_status}
       </div>
    </div>
    {/profile}
    <div id="user_info">
       <p>Посты в блоге ( {count_blogs} )</p>
       {has_blogs}
       <table cellpadding="0" cellspacing="0" id="user_posts">
          {blogs}
          <tr id="odd_even_styles">
             <td class="user_post" style="width:700px;">{blog_title}</td>
             <td style="width:170px;">{blog_date_posted}</td>
          </tr>
          {/blogs}
       </table>
       {/has_blogs}
    </div>
    <div id="user_info">
       <p>Комментарии к постам ( {count_comments} )</p>
       {has_comments}
       <table cellpadding="0" cellspacing="0" id="user_posts">
          {comments}
          <tr id="odd_even_styles">
             <td class="user_post" style="width:700px;">{blog_title}</td>
             <td style="width:170px;">{com_date_posted}</td>
          </tr>
          {/comments}
       </table>
       {/has_comments}
    </div>
    <div id="user_info">
       <p>Сообщения на форуме ( отсутствуют )</p>
    </div>
</div>