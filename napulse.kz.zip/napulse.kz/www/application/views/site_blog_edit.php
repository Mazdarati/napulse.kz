<div id="content">
    <div id="page_title">
        Редактировать пост
        <?=$this->form_validation->error_string(); ?>
        <?=$error;?>
    </div>
    <form method="post" enctype="multipart/form-data">
        {blog}
        <p>Заголовок: <input name="post_title" type="text" value="{blog_title}" /></p>
        <p>Короткая информация: <textarea name="post_short_info">{blog_short_info}</textarea></p>
        <p>Обложка: <input type="file" name="userfile" size="20" value="{blog_photo}" /></p>
        <p>Содержимое: <textarea name="post_content">{blog_content}</textarea></p>
        <p>Категория: <select name="post_category">{category_list}<option value="{cat_id}">{cat_title}</option>{/category_list}</select></p>
        <p>Теги: <textarea name="post_cloud">{blog_tags}</textarea></p>
        {/blog}
        <input type="submit" value="Изменить" />
    </form>
</div>