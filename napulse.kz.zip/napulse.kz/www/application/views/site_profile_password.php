<div id="content">
    <div id="page_title">
       Изменить пароль
    </div>
    {profile}
    <div class="user_info">
       <div class="user_photo"></div>
       <div id="user_name">{user_surname}&nbsp;{user_name}</div>
       <div id="user_desc">
          Логин: {user_login}<br/>
          Группа: {user_type}<br/>
          Статус: {user_status}
       </div>
    </div>
    <div id="user_info"  align="center">
        <?=$this->form_validation->error_string(); ?>
        <form method="post">
            <table cellpadding="0" cellspacing="0">
                <tbody>
                <tr>
                    <td>Текущий пароль:</td>
                    <td><input type="text" name="cur_password"/></td>    
                </tr>
                <tr>
                    <td>Новый пароль:</td>
                    <td><input type="text" name="new_password"/></td>    
                </tr>
                <tr>
                    <td>Подтверждение:</td>
                    <td><input type="text" name="confirm_password"/></td>    
                </tr>
                <tr >
                    <td colspan="2" align="center"><br /><input type="submit" value="Сохранить" /></td>    
                </tr>
                </tbody>
            </table>
        {/profile}
        </form>
    </div>
</div>