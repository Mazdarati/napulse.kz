<div id="content">
    <div id="page_title">
        Добавить раздел
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="title" type="text" /></p>
        <input type="submit" value="Добавить" />
    </form>
</div>