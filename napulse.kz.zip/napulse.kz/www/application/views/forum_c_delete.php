<div id="content">
    Вы действительно, хотите удалить этот раздел?
    <?=$this->form_validation->error_string(); ?>
    <form method="post">
        <input type="hidden" name="rem" value="1" />
        <input type="submit" value="Да" />
        <a href="javascript:history.back();">НЕТ</a>
    </form>
</div>