<div id="content">
    <table cellpadding="0" cellspacing="1" id="contact">
        <tr>
            <td colspan="2" id="page_title">
                СВЯЖИТЕСЬ С НАМИ
            </td>
        </tr>
        <tr>
            <td colspan="2" style="color:#669999;font-size:11pt;padding-bottom:20px;">
                Для того чтобы связаться с нами:
                <?=$this->form_validation->error_string(); ?>
            </td>
        </tr>
        <tr style="color:#669999;font-size:11pt;">
            <td id="description">
                Отправьте нам сообщение
            </td>
            <td id="description">
                Или воспользуйтесь нашими контактами
            </td>
        </tr>
        <tr>
            <td>
                <form method="POST">
                    <table cellpadding="5" cellspacing="0" style="padding-top:10px;width:100%;">
                        <tr>
                            <td id="contact_msg_des">
                                Вас зовут:
                            </td>
                            <td style="width:75%;">
                                <input name="username" type="text" style="width:85%;"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Ваш Email:
                            </td>
                            <td>
                                <input name="email" type="text" style="width:85%;"/>
                            </td>
                        </tr>
                        <tr>
                            <td id="contact_msg_des">
                                Тема:
                            </td>
                            <td>
                                <input name="theme" type="text" style="width:85%;"/>
                            </td>                                
                        </tr>
                        <tr>
                            <td valign="top" style="padding-top:15px;">
                                Сообщение:
                            </td>
                            <td>
                                <textarea name="content" rows="10" style="margin:8px 0px 8px 0px;"></textarea>
                            </td>                                
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" style="width:89%;" value="Отправить сообщение"/>
                            </td>                                
                        </tr>                                                                                                                            
                    </table>
                </form>                            
            </td>
            <td valign="top">
                <?$this->view('site_view_contact');?>
            </td>
        </tr>
    </table>
</div>