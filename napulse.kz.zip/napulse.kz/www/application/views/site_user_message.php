<div id="content">
    <div id="page_title">
       Написать сообщение
    </div>
    {profile}
    <div class="user_info">
       <div class="user_photo"></div>
       <div id="user_name">{user_surname}&nbsp;{user_name}</div>
       <div id="user_desc">
          Логин: {user_login}<br/>
          Группа: {user_type}<br/>
          Статус: {user_status}
       </div>
    </div>
    <div id="user_info"  align="center">
        <?=$this->form_validation->error_string(); ?>
        <form method="post">
            <table cellpadding="0" cellspacing="0">
                <tbody>
                <tr>
                    <td>Тема :</td>
                    <td><input type="text" name="theme" value="{user_surname}" /></td>    
                </tr>
                <tr><td><br /></td></tr>
                <tr>
                    <td valign="top">Содержание :</td>
                    <td><textarea name="content" cols="15" rows="10"></textarea></td>    
                </tr>
                <tr >
                    <td colspan="2" align="center"><br /><input type="submit" value="Отправить" /></td>    
                </tr>
                </tbody>
            </table>
        {/profile}
        </form>
    </div>
</div>