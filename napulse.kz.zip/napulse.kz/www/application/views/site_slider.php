<div id="preview">
    <div id="slider"></div>
    <div id="preview_items"></div>
</div>