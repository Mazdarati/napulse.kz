<div id="content">
    <div id="page_title">
        Добавить категорию
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="post_title" type="text" /></p><br />
        <input type="submit" value="Добавить" />
    </form>
</div>