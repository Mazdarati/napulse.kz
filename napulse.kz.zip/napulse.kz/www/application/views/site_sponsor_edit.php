<div id="content">
    <div id="page_title">
        Редактировать спонсора
        <?=$this->form_validation->error_string(); ?>
        <?=$error;?>
    </div>
    <form method="post" enctype="multipart/form-data">
        {partner}
        <p>Название: <input name="title" type="text" value="{partner_title}" /></p>
        <p>Лого: <input type="file" name="userfile" size="20" value="{partner_image}" /></p>
        <p>Описание: <textarea name="content">{partner_descr}</textarea></p>
        {/partner}
        <input type="submit" value="Редактировать" />
    </form>
</div>