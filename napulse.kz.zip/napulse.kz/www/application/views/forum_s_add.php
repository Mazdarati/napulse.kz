<div id="content">
    <div id="page_title">
        Добавить категорию
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Заголовок: <input name="title" type="text" /></p>
        <p>Короткая информация: <textarea name="short_info"></textarea></p>
        <p>Раздел: <select name="category_id">{category_list}<option value="{id}">{title}</option>{/category_list}</select></p>
        <input type="submit" value="Добавить" />
    </form>
</div>