<div id="content">
    <?=$this->form_validation->error_string(); ?>
    {info_post}
    <form method="post">
        <textarea name="subject">{subject}</textarea>
        <input type="submit" value="Редактировать" />
    </form>
    {/info_post}
</div>