<div id="content">
    {mod_on}<div><a href="/forum/posting/reply/p/{post_id}"><button class="add_cat_sub">Написать</button></a></div>{/mod_on}{pagination}
    <div id="forum">
        {forum}
        <table cellpadding="0" cellspacing="0" class="f_table_msg" id="msg{msg_id}">
            <tbody>
                <tr>
                    <td class="td_info"><a href="/user/{user_login}/show">{user_login}</a><div style="float: right;">#{msg_id}</div><br /><span class="f_user_type">{user_type}</span><br /><br /><span class="f_user_post">Постов: {user_count_post}<br />Сообщении: {user_count_msg}</span></td>
                    <td class="td_content">{subject}<br /><br /><div class="f_date">{own_msg}<a href="/forum/posting/reply/p/{post_id}/m/{msg_id}">Ответить</a><?=nbs(4);?>Добавлен: {date}{has_reply}</div></td>
                </tr>
            </tbody>
        </table>
        {/forum}
    </div>
    {statistic}
    <div id="f_common">
        <div class="f_statistic"><tt>Статистика:</tt></div>
        <div class="f_info"><b>Онлайн</b>: пользователей: <b>{online_user}</b> ; гостей: <b>{online_guests}</b><br />Разделов : <b>{count_category}</b> | Категорий: <b>{count_subcategory}</b> |Сообщений: <b>{count_messages}</b> | Тем: <b>{count_posts}</b> | Пользователей: <b>{count_users}</b></div>
    </div>
    {/statistic}
</div>