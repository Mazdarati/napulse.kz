        <div id="footer">© 2012 napulse.kz | <a href="/contact">Наши контакты</a> | Сделано в <a href="http://www.truebrains.kz" target="_blank"><b>TrueBrains</b></a></div>
        </div>
    </body>
</html>