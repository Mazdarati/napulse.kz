<div id="top_bar">
    <a id="home_link" href="/"></a>
    <form method="get" action="/forum/search/" style="float: left;"><input id="search_button" type="submit" value=""/><input name="q" id="search_input" onfocus="this.value='';" onblur="if (this.value != '') {this.onfocus = function(){};} else this.value='Поле для поиска';" type="text" value="Поле для поиска"/></form>
    <? if(!$this->session->userdata('logged_in')): ?>
    <a class="links" id="signup_link" href="/signup">Регистрация</a>
    <a class="links" id="login_link" href="/login">Вход</a>
    <? else : ?>
    <a class="links" href="/logout">Выход</a>
    <a class="links" href="/user/<?=$this->session->userdata('login');?>"><?=$this->session->userdata('login');?></a>
    <? endif; ?>
</div>
<div id="quote">
    <a id="button_add" href="/history"></a>
</div>
<div id="menu_bar">
    <a style="{link_purpose_active}" href="/purpose">Цель проекта</a><a style="{link_news_active}" href="/news">Архив</a><a style="{link_consultation_active}" href="/consultation">Консультация</a><a style="{link_blog_active}" href="/blog">Блог</a><a style="{link_forum_active}" href="/forum">Форум</a><a style="{link_sponsor_active}" href="/sponsor">Партнеры</a>
</div>