<div id="content">
    <div id="page_title">
        БЛОГ САЙТА
    </div>
    <div id="blog">
        {blog_data}
        <div id="post">
            <div id="post_image">
                <img src="{blog_photo}"/>
            </div>
            <div id="post_title">{blog_title}</div>
            <div id="post_text">{blog_content}</div>
            <div class="inform" id="post_info">{new_like}<a href="">[LIKE]</a> {/new_like}{blog_date_posted} | Добавил <a href="<?=base_url();?>user/"><b>{user_login}</b></a></div>
            <div id="comments">
                <div id="comments_info">{blog_count_com} комментария к посту</div>
                {new_comment}
                <br />
                <?=$this->form_validation->error_string(); ?>
                <form method="post">
                    <p><textarea name="post_content"></textarea></p>
                    <input type="hidden" name="request_user_id" value="" />
                    <input type="submit" value="Добавить комментарий" />
                </form>
                {/new_comment}
                {edit_comment}
                <?=$this->form_validation->error_string(); ?>
                <form method="post">
                    {data_current_comment}
                    <p><textarea name="post_content">{com_content}</textarea></p>
                    <input type="hidden" name="request_user_id" value="{request_user_id}" />
                    <input type="submit" value="Редактировать комментарий" />
                    {/data_current_comment}
                </form>
                {/edit_comment}
                {comment_data}
                <div id="comment">
                    <div id="comment_text">{com_content}</div>
                    <div class="inform" id="comment_info">{com_date_posted} | Добавил <a href="<?=base_url();?>user/">{user_login}</a></div>
                </div>
                {/comment_data}
            </div>
        </div>
        {/blog_data}
    </div>
    <?php $this->view('site_sidebar');?>   
</div>