<div id="content">
    <div id="page_title">
        Редактировать тэг
        <?=$this->form_validation->error_string(); ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        {tags}
        <p>Заголовок: <input name="post_title" type="text" value="{cloud_title}" /></p><br />
        {/tags}
        <input type="submit" value="Редактировать" />
    </form>
</div>