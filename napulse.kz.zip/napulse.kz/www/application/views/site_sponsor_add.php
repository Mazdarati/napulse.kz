<div id="content">
    <div id="page_title">
        Добавить спонсора
        <?=$this->form_validation->error_string(); ?>
        <?=$error;?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <p>Название: <input name="title" type="text" /></p>
        <p>Лого: <input type="file" name="userfile" size="20" /></p>
        <p>Описание: <textarea name="content"></textarea></p>
        <input type="submit" value="Добавить" />
    </form>
</div>