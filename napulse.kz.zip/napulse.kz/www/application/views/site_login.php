<script>
$('#close').click(function(){
    $('#sign_form').hide(400, function(){$('#sign_form').html("");});
    window.history.back();
});
         
$('.restore').toggle(function(e){
    e.preventDefault();
    $('#sign_form').load('restore.php');
    $('#sign_form').hide();
    $('#sign_form').show(400);
},function(){
      $('#sign_form').hide(400, function(){$('#sign_form').html("");});
});
		
</script>
<div id="sign_backgr">
    <form method="post" action="/login">
        <table cellpadding="0" cellspacing="1" class="sign" id="login">
            <tr>
                <td colspan="2" id="page_title">
                    <div id="close">CLOSE</div>
                    ДОБРО ПОЖАЛОВАТЬ! 
                </td>
            </tr>
            <tr>
                <td colspan="2" class="prescription">
                    Для входа на сайт:
                </td>
            </tr>
            <tr>
                <td colspan="2" class="description" id="sign_des" >
                    Введите данные
                    <?=$this->form_validation->error_string(); ?>
                </td>
            </tr>
            <tr>
                <td>
                    <table cellpadding="0" cellspacing="0" style="padding-bottom:10px;width:100%;">
                        <tr>
                            <td id="input_def">
                                Логин пользователя или Email:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="log_or_email" />
                            </td>
                        </tr>
                        <tr>
                            <td id="input_def">
                                Пароль:
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="password" name="pass" />
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" class="description" id="sign_des" style="font-size:10pt;">
                    <a href="#" class="restore">Забыли пароль?</a>
                </td>
            </tr>
            <tr>
                <td style="padding:10px 0px 10px 0px;">
                    <input type="submit" value="Войти"/>
                </td>
            </tr>
        </table>
    </form>
</div>