<?php

/**
 * @author miracle
 * @copyright 2012
 */

if ( !defined('BASEPATH') ) exit('No direct script access allowed');

$config['first_link'] = 'В начало';
$config['last_link'] = 'Последний';
$config['next_link'] = 'Далее';
$config['prev_link'] = 'Назад';
$config['cur_tag_open'] = '<b>';
$config['cur_tag_close'] = '</b>';
$config['full_tag_open'] = '<div class="pages" style="margin-bottom:15px;">';
$config['full_tag_close'] = '</div>';


?>