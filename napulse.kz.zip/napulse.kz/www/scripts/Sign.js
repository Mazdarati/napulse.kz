function Sign()
{
    
    $(document).ready(function(){
    	$('#login_link').click(function(e)
        {
            e.preventDefault();
            $('#sign_form').load('/login');
            $('#sign_form').hide();
            $('#sign_form').show(400);
            history.pushState({auth: 'login'}, 'Login', '/login');
		});
	
	   $('#signup_link').click(function(e)
       {
            e.preventDefault();
            $('#sign_form').load('/signup');
            $('#sign_form').hide();
            $('#sign_form').show(400);
            history.pushState({auth: 'signup'}, 'Registration', '/signup');
       });
       
    });
}